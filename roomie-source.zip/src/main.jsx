import React, { useState, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  Heart,
  House,
  Compass,
  Users,
  User,
  SlidersHorizontal,
  X,
  RotateCcw,
  MapPin,
  GraduationCap,
  Check,
  ChevronRight,
  Sparkles,
  Moon,
  Coffee,
  PawPrint,
  Menu,
  ArrowUpRight,
  MessageCircle,
} from "lucide-react";
import { defaultProfile, people as demoPeople } from "./data";
import { photos } from "./photos";
const demoList = demoPeople.map((p) => ({ ...p, photo: photos[p.id] }));
import "./style.css";
import ScenarioLab from "./ScenarioLab";
import AiAdvice from "./AiAdvice";
import { rank, fit, scenarioBreakdown, scenarioExplanation } from "./scenarios";
import { isSupabaseConfigured } from "./real/supabase";
import RealApp from "./real/RealApp";
import BasicAuth, { currentUser, logout as basicLogout } from "./BasicAuth";
import { localPeople, addMatchForOther, removeMatchForOther, isLocalId } from "./localUsers";
function read(k, f) {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? f;
  } catch {
    return f;
  }
}
function save(k, v) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {}
}
function Avatar({ p, className = "" }) {
  return (
    <div
      className={"avatar " + className}
      style={{ background: p.color || "#d9cef5" }}
    >
      <span>{p.initial || p.name[0]}</span>
      {p.photo && (
        <img
          src={p.photo}
          style={{ objectPosition: p.photoPosition || "center 35%" }}
          alt={p.name}
          onError={(e) => (e.currentTarget.style.display = "none")}
        />
      )}
    </div>
  );
}
function App({ onExit, user, onLogout }) {
  const k = (key) => (user ? `${key}:${user}` : key);
  // Sample profiles plus every other account signed up in this browser.
  const people = [...demoList, ...(user ? localPeople(user) : [])];
  const [answers, setAnswers] = useState(() => read(k("roomie-v2-scenarios"), []));
  const changeAnswers = (a) => {
    setAnswers(a);
    save(k("roomie-v2-scenarios"), a);
  };
  const [profile, setProfile] = useState(() =>
    read(k("roomie-profile"), defaultProfile),
  );
  const [ready, setReady] = useState(() => read(k("roomie-ready"), false));
  const [page, setPage] = useState("vibes");
  const [swipes, setSwipes] = useState(() => read(k("roomie-v2-swipes"), []));
  const [matches, setMatches] = useState(() =>
    read(k("roomie-v2-matches"), []).filter((id) =>
      people.some((p) => p.id === id),
    ),
  );
  const [modal, setModal] = useState(null);
  const [direction, setDirection] = useState("");
  const [filters, setFilters] = useState(false);
  const [maxBudget, setMaxBudget] = useState(2000);
  const [schoolOnly, setSchoolOnly] = useState(false);
  const [drag, setDrag] = useState(0);
  const start = useRef(null);
  const busy = useRef(false);
  const candidates = rank(profile, people, answers).filter(
    (p) =>
      !swipes.some((s) => s.id === p.id) &&
      p.budget <= maxBudget &&
      (!schoolOnly || p.school === profile.school),
  );
  const person = candidates[0];
  function swipe(like) {
    if (!person || busy.current) return;
    busy.current = true;
    setDirection(like ? "right" : "left");
    setTimeout(() => {
      const next = [...swipes, { id: person.id, like }];
      setSwipes(next);
      save(k("roomie-v2-swipes"), next);
      if (like && person.likedYou) {
        const list = [...matches, person.id];
        setMatches(list);
        save(k("roomie-v2-matches"), list);
        if (person.local) addMatchForOther(person.id, user);
        setModal({ type: "match", p: person });
      }
      setDirection("");
      setDrag(0);
      busy.current = false;
    }, 280);
  }
  function undo() {
    if (!swipes.length || busy.current) return;
    const last = swipes.at(-1);
    const next = swipes.slice(0, -1);
    setSwipes(next);
    save(k("roomie-v2-swipes"), next);
    const list = matches.filter((id) => id !== last.id);
    setMatches(list);
    save(k("roomie-v2-matches"), list);
    if (isLocalId(last.id) && matches.includes(last.id)) removeMatchForOther(last.id, user);
  }
  function update(p) {
    setProfile(p);
    save(k("roomie-profile"), p);
    setReady(true);
    save(k("roomie-ready"), true);
    setModal(null);
  }
  return (
    <>
      <aside className="sidebar">
        <a className="brand" href="#" onClick={(e) => e.preventDefault()}>
          <span className="brand-icon">
            <House size={23} />
          </span>
          roomie<span className="brand-dot">.</span>
        </a>
        <div className="workspace-label">YOUR SPACE, YOUR PEOPLE</div>
        <nav>
          {[
            ["vibes", Sparkles, "Your vibe"],
            ["discover", Compass, "Discover"],
            ["matches", Heart, "Your matches"],
            ["profile", User, "My profile"],
          ].map(([id, Icon, label]) => (
            <button
              key={id}
              className={page === id ? "nav active" : "nav"}
              onClick={() => setPage(id)}
            >
              <Icon size={21} />
              {label}
              {id === "matches" && matches.length > 0 && (
                <b className="badge">{matches.length}</b>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-note">
          <div className="mini-house">
            <House size={25} />
            <Heart size={15} />
          </div>
          <h3>
            A good roommate.
            <br />A better chapter.
          </h3>
          <p>Your next favorite person might be one swipe away.</p>
          <span>
            Made for student living <Sparkles size={14} />
          </span>
        </div>
        <button className="account" onClick={() => setPage("profile")}>
          <MyAvatar profile={profile} className="account-avatar" />
          <div>
            <b>{profile.name}</b>
            <small>{user ? `@${user}` : "Student · Demo profile"}</small>
          </div>
          <ChevronRight size={16} />
        </button>
      </aside>
      <div className="main">
        <header>
          <div className="breadcrumb">
            Your next chapter starts here <span>✦</span>
          </div>
          <span className="demo-pill">
            <span />
            Demo mode · sample profiles
          </span>
          {onExit && (
            <button className="logout-button" onClick={onExit}>
              Sign in for real matching
            </button>
          )}
          {onLogout && (
            <button className="logout-button" onClick={onLogout}>
              Log out
            </button>
          )}
        </header>
        <div className="demo-banner" role="note">
          <b>Demo mode.</b> {user ? "Your account and profile are saved in this browser, and other accounts signed up in this browser show up in Discover. " : ""}The four named profiles are samples
          with invented lifestyle answers. Likes and matches are simulated and stay in this browser.
        </div>
        <main>
          <div className="page-title">
            <div>
              <div className="eyebrow">FIND YOUR PEOPLE</div>
              <h1>
                {page === "vibes"
                  ? "Don’t describe it. Swipe it."
                  : page === "discover"
                    ? "Good vibes. Great roommates."
                    : page === "matches"
                      ? "A connection worth keeping."
                      : "Make yourself at home."}
              </h1>
              <p>
                {page === "vibes"
                  ? "Real-life moments. Four ways to react. A ranking that adapts."
                  : page === "discover"
                    ? "Your scenario choices shape who you see first."
                    : page === "matches"
                      ? "Your mutual likes, all in one place."
                      : "A little about you goes a long way toward a better match."}
              </p>
            </div>
            {page === "discover" && (
              <button
                className="filter-button"
                onClick={() => setFilters(!filters)}
              >
                <SlidersHorizontal size={17} />
                Filters
                {(maxBudget < 2000 || schoolOnly) && (
                  <span className="filter-dot" />
                )}
              </button>
            )}
          </div>
          {page === "vibes" && (
            <ScenarioLab
              answers={answers}
              onAnswers={changeAnswers}
              profile={profile}
              people={people}
              onExplore={() => setPage("discover")}
            />
          )}
          {!ready && page === "discover" && (
            <div className="onboard-banner">
              <span>
                <Sparkles size={18} />
                Your budget and basics.{" "}
                <small>
                  Explore scenarios to learn your lifestyle preferences.
                </small>
              </span>
              <button onClick={() => setModal({ type: "onboard" })}>
                Create your profile <ChevronRight size={16} />
              </button>
            </div>
          )}
          {filters && page === "discover" && (
            <div className="filter-panel">
              <label>
                Maximum budget: ${maxBudget}
                <input
                  type="range"
                  min="600"
                  max="2000"
                  step="50"
                  value={maxBudget}
                  onChange={(e) => setMaxBudget(+e.target.value)}
                />
              </label>
              <label className="checkbox">
                <input
                  type="checkbox"
                  checked={schoolOnly}
                  onChange={(e) => setSchoolOnly(e.target.checked)}
                />{" "}
                My university only
              </label>
              <button
                className="text-button"
                onClick={() => {
                  setMaxBudget(2000);
                  setSchoolOnly(false);
                }}
              >
                Clear filters
              </button>
            </div>
          )}
          {page === "discover" && (
            <div className="discovery min-w-0">
              <section className="swipe-area">
                <div className="deck-heading">
                  <span>
                    <span className="live-dot" /> YOUR NEXT ROOMMATE?
                  </span>
                  <small>{candidates.length} profiles to explore</small>
                </div>
                {person ? (
                  <>
                    <div className="card-stack">
                      <div className="stack-back" />
                      <article
                        className={`profile-card ${direction}`}
                        style={{
                          transform: drag
                            ? `translateX(${drag}px) rotate(${drag / 20}deg)`
                            : undefined,
                        }}
                        onPointerDown={(e) => {
                          if (e.target.closest("button")) return;
                          start.current = e.clientX;
                          e.currentTarget.setPointerCapture(e.pointerId);
                        }}
                        onPointerMove={(e) => {
                          if (start.current !== null)
                            setDrag(e.clientX - start.current);
                        }}
                        onPointerUp={() => {
                          if (drag > 80) swipe(true);
                          else if (drag < -80) swipe(false);
                          setDrag(0);
                          start.current = null;
                        }}
                        onPointerCancel={() => {
                          setDrag(0);
                          start.current = null;
                        }}
                      >
                        <div className="hero-photo">
                          <Avatar p={person} />
                          <span className="student-tag">
                            <GraduationCap size={14} />
                            {person.local ? "Roomie member" : "Sample lifestyle data"}
                          </span>
                          <div className="photo-gradient" />
                          <div className="photo-name">
                            <h2>
                              {person.name}, {person.age}{" "}
                            </h2>
                            <p>
                              <MapPin size={15} />
                              {person.local ? `@${person.username}` : "HackJam demo profile"}
                            </p>
                          </div>
                          <button
                            className="compat-pill"
                            onClick={() =>
                              setModal({ type: "details", p: person })
                            }
                          >
                            <Sparkles size={15} />
                            {answers.length
                              ? fit(profile, person, answers) + "% fit"
                              : "Explore your vibe"}
                          </button>
                          {Math.abs(drag) > 40 && (
                            <div
                              className={`swipe-stamp ${drag > 0 ? "like" : ""}`}
                            >
                              {drag > 0 ? "LIKE" : "PASS"}
                            </div>
                          )}
                        </div>
                        <div className="card-body">
                          <div className="school">
                            <GraduationCap size={17} />
                            <div>
                              {person.school}
                              <small>
                                {person.major} · $
                                {person.budget.toLocaleString()}/mo budget
                              </small>
                            </div>
                          </div>
                          <p className="bio">{person.bio}</p>
                          <div className="tags">
                            {person.interests.map((t) => (
                              <span key={t}>
                                {t === "Coffee"
                                  ? "☕ "
                                  : t === "Design"
                                    ? "✧ "
                                    : t === "Basketball"
                                      ? "🏀 "
                                      : ""}
                                {t}
                              </span>
                            ))}
                          </div>
                        </div>
                      </article>
                    </div>
                    <div className="swipe-controls">
                      <button
                        className="undo"
                        onClick={undo}
                        disabled={!swipes.length}
                        aria-label="Undo last swipe"
                      >
                        <RotateCcw size={21} />
                      </button>
                      <button
                        className="pass"
                        onClick={() => swipe(false)}
                        aria-label="Pass on profile"
                      >
                        <X size={31} />
                      </button>
                      <button
                        className="like"
                        onClick={() => swipe(true)}
                        aria-label="Like profile"
                      >
                        <Heart size={29} fill="currentColor" />
                      </button>
                    </div>
                    <p className="swipe-hint">
                      Swipe or tap. Your kind of people are out there.
                    </p>
                  </>
                ) : (
                  <div className="empty-state">
                    <Sparkles size={40} />
                    <h2>You’re all caught up.</h2>
                    <p>
                      Try changing your filters or revisit the demo profiles.
                    </p>
                    <button
                      className="primary"
                      onClick={() => {
                        setSwipes([]);
                        save(k("roomie-v2-swipes"), []);
                        setMatches([]);
                        save(k("roomie-v2-matches"), []);
                        setMaxBudget(2000);
                        setSchoolOnly(false);
                      }}
                    >
                      Restart demo
                    </button>
                  </div>
                )}
              </section>
              <aside className="insights">
                <div className="insight-card">
                  <div className="insight-title">
                    <span className="sparkle-box">
                      <Sparkles size={21} />
                    </span>
                    <span>
                      Your choices change the order.
                      <small>COMPATIBILITY THAT COUNTS</small>
                    </span>
                  </div>
                  <p>
                    Shared habits make happy homes. Scenario swipes update a
                    weighted preference model in real time.
                  </p>
                  <div className="habit">
                    <span>💸</span>
                    <div>
                      <b>A budget that works</b>
                      <small>Same range. Less rent stress.</small>
                    </div>
                  </div>
                  <div className="habit">
                    <span>✨</span>
                    <div>
                      <b>Your kind of clean</b>
                      <small>A shared space you both love.</small>
                    </div>
                  </div>
                  <div className="habit">
                    <span>☾</span>
                    <div>
                      <b>Routines that click</b>
                      <small>Night owl? Early bird? We get it.</small>
                    </div>
                  </div>
                  <div className="habit">
                    <span>♧</span>
                    <div>
                      <b>Little things, big difference</b>
                      <small>Guests, pets, and everyday life.</small>
                    </div>
                  </div>
                  <div className="insight-footer">
                    <Heart size={15} /> Built for living well together.
                  </div>
                </div>
                <div className="tip">
                  <span>✦</span>
                  <div>
                    <b>A little roomie wisdom</b>
                    <p>
                      The best roommate isn’t always your twin. Look for shared
                      values, and room to be yourself.
                    </p>
                  </div>
                </div>
                <div className="demo-note">
                  DEMO MODE <span>·</span> REAL POSSIBILITIES
                  <p>
                    Named demo profiles with invented lifestyle preferences.
                    Matches are simulated and saved in this browser only.
                  </p>
                </div>
              </aside>
            </div>
          )}
          {page === "matches" && (
            <>
              <div className="section-label">
                {matches.length} mutual{" "}
                {matches.length === 1 ? "connection" : "connections"}
              </div>
              {matches.length ? (
                <div className="matches-grid">
                  {matches.map((id) => {
                    const p = people.find((x) => x.id === id);
                    return (
                      <article className="match-card" key={id}>
                        <Avatar p={p} />
                        <div>
                          <span className="match-score">
                            {answers.length
                              ? fit(profile, p, answers) + "% sample fit"
                              : "Awaiting scenarios"}
                          </span>
                          <h2>
                            {p.name}, {p.age}
                          </h2>
                          <p>{p.major}</p>
                          <button
                            className="primary"
                            onClick={() => setModal({ type: "details", p })}
                          >
                            Get to know {p.name}
                          </button>
                        </div>
                      </article>
                    );
                  })}
                </div>
              ) : (
                <div className="empty-state">
                  <Heart size={42} />
                  <h2>Your people are out there.</h2>
                  <p>
                    Like a profile. If they’ve liked you too, you’ll connect
                    here.
                  </p>
                  <button
                    className="primary"
                    onClick={() => setPage("discover")}
                  >
                    Explore profiles
                  </button>
                </div>
              )}
            </>
          )}
          {page === "profile" && (
            <div className="profile-layout">
              <div className="profile-intro">
                <MyAvatar profile={profile} className="large-avatar" />
                <h2>
                  {profile.name}, {profile.age}
                </h2>
                <p>{profile.school}</p>
                <span className="demo-pill">Browser-local profile</span>
                <p>
                  Budget comes from this profile. Lifestyle preferences come
                  from Your vibe scenario swipes.
                </p>
              </div>
              <ProfileForm
                profile={profile}
                onSave={(p) => {
                  update(p);
                  setModal({ type: "saved" });
                }}
              />
            </div>
          )}
          <footer>
            <span>
              roomie. <small>A place to belong.</small>
            </span>
            <small>Made with a little love & a lot of possibility.</small>
          </footer>
        </main>
      </div>
      {modal && (
        <div className="modal-backdrop isolate" onClick={() => setModal(null)}>
          <section
            role="dialog"
            aria-modal="true"
            aria-label="Roomie dialog"
            className={"modal " + (modal.type === "onboard" ? "wide" : "")}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="close"
              aria-label="Close dialog"
              onClick={() => setModal(null)}
            >
              <X />
            </button>
            {modal.type === "onboard" ? (
              <>
                <div className="eyebrow">LET’S MAKE IT YOURS</div>
                <h2>Your next chapter starts with you.</h2>
                <p>
                  Add your basics here, then swipe real-life scenarios in Your
                  vibe.
                </p>
                <ProfileForm profile={profile} onSave={update} />
              </>
            ) : modal.type === "saved" ? (
              <div className="match-celebration">
                <Check size={48} />
                <h2>You’re all set.</h2>
                <p>Your profile and compatibility scores are updated.</p>
                <button className="primary" onClick={() => setModal(null)}>
                  Keep exploring
                </button>
              </div>
            ) : modal.type === "match" ? (
              <div className="match-celebration">
                <Sparkles size={38} />
                <div className="match-avatars">
                  <MyAvatar profile={profile} className="large-avatar" />
                  <Heart fill="currentColor" />
                  <Avatar p={modal.p} />
                </div>
                <div className="eyebrow">THE FEELING IS MUTUAL</div>
                <h2>It’s a roomie match!</h2>
                <p>
                  You and {modal.p.name} liked each other.
                  <br />
                  This could be the start of a great chapter.
                </p>
                <small>
                  {modal.p.local
                    ? "You both liked each other."
                    : "Simulated mutual match with a demo profile."}
                </small>
                <button
                  className="primary"
                  onClick={() => {
                    setPage("matches");
                    setModal(null);
                  }}
                >
                  See your matches
                </button>
                <button className="text-button" onClick={() => setModal(null)}>
                  Keep discovering
                </button>
              </div>
            ) : (
              <>
                <Avatar className="details-avatar" p={modal.p} />
                <h2>You + {modal.p.name}</h2>
                <p className="big-score">
                  {answers.length
                    ? fit(profile, modal.p, answers) + "% sample fit"
                    : "Explore scenarios first"}
                </p>
                <div className="breakdown">
                  {scenarioBreakdown(profile, modal.p, answers).map((x) => (
                    <div key={x.label}>
                      <span>
                        {x.label}
                        <small>{x.detail}</small>
                      </span>
                      <div className="meter">
                        <i style={{ width: x.value + "%" }} />
                      </div>
                      <b>{x.value}%</b>
                    </div>
                  ))}
                </div>
                <div className="explanation">
                  <Sparkles size={19} />
                  <p>{scenarioExplanation(profile, modal.p, answers)}</p>
                </div>
                <AiAdvice
                  key={modal.p.id + JSON.stringify(answers)}
                  profile={profile}
                  person={modal.p}
                  answers={answers}
                />
                <p className="conversation">
                  <b>Start the conversation</b>
                  <br />
                  “What does your ideal weekday at home look like?”
                </p>
              </>
            )}
          </section>
        </div>
      )}
    </>
  );
}
function MyAvatar({ profile, className }) {
  return (
    <div className={className + " my-avatar"}>
      {profile.photo ? <img src={profile.photo} alt={profile.name || "Your photo"} /> : (profile.name || "?")[0]}
    </div>
  );
}
// Shrinks a picked photo to a small JPEG data URL so it fits in browser storage
// (this also drops the original file's location metadata).
function photoToDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type))
      return reject(new Error("Use a JPEG, PNG, or WebP image."));
    if (file.size > 15 * 1024 * 1024) return reject(new Error("That photo is too large (max 15 MB)."));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, 400 / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Couldn’t read that image. Try another one."));
    };
    img.src = url;
  });
}
function ProfileForm({ profile, onSave }) {
  const [d, setD] = useState(profile);
  const [photoError, setPhotoError] = useState("");
  const fileRef = useRef(null);
  const change = (key, value) => setD({ ...d, [key]: value });
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSave({ ...d, name: d.name.trim() || "Student" });
      }}
    >
      <div className="photo-row">
        <MyAvatar profile={d} className="large-avatar form-avatar" />
        <div>
          <b>
            Profile photo <small className="optional">Optional</small>
          </b>
          <p className="form-note">JPEG, PNG, or WebP. Saved in this browser only.</p>
          <div className="photo-actions">
            <button type="button" className="secondary" onClick={() => fileRef.current?.click()}>
              {d.photo ? "Change photo" : "Add photo"}
            </button>
            {d.photo && (
              <button type="button" className="text-button" onClick={() => change("photo", null)}>
                Remove
              </button>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            hidden
            aria-label="Profile photo"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              setPhotoError("");
              try {
                change("photo", await photoToDataUrl(file));
              } catch (err) {
                setPhotoError(err.message);
              }
            }}
          />
          {photoError && (
            <p className="auth-error" role="alert">
              {photoError}
            </p>
          )}
        </div>
      </div>
      <div className="form-grid">
        <label>
          Your name
          <input
            required
            maxLength="40"
            value={d.name}
            onChange={(e) => change("name", e.target.value)}
          />
        </label>
        <label>
          Age
          <input
            type="number"
            required
            min="18"
            max="99"
            value={d.age}
            onChange={(e) => change("age", +e.target.value)}
          />
        </label>
        <label className="full">
          University
          <input
            required
            maxLength="100"
            value={d.school}
            onChange={(e) => change("school", e.target.value)}
          />
        </label>
        <label className="full">
          Major
          <input
            required
            maxLength="80"
            value={d.major}
            onChange={(e) => change("major", e.target.value)}
          />
        </label>
        <label className="full">
          A little about you
          <textarea
            maxLength="350"
            value={d.bio}
            onChange={(e) => change("bio", e.target.value)}
          />
        </label>
        <label className="full">
          Monthly rent budget · ${d.budget}
          <input
            type="range"
            min="500"
            max="2500"
            step="50"
            value={d.budget}
            onChange={(e) => change("budget", +e.target.value)}
          />
        </label>
      </div>
      <button className="primary save-profile" type="submit">
        Save my profile <Check size={17} />
      </button>
      <p className="form-note">
        Saved to your account in this browser only.
      </p>
    </form>
  );
}
function BasicRoot() {
  const [user, setUser] = useState(() => currentUser());
  const [ready, setReady] = useState(() => (user ? read(`roomie-ready:${user}`, false) : false));
  if (!user)
    return (
      <BasicAuth
        onLogin={(u) => {
          setUser(u);
          setReady(read(`roomie-ready:${u}`, false));
        }}
      />
    );
  const doLogout = () => {
    basicLogout();
    setUser(null);
  };
  if (!ready)
    return (
      <div className="auth-page">
        <section className="auth-card wide">
          <div className="onboarding-top">
            <div className="auth-brand">
              <span className="brand-icon">
                <House size={23} />
              </span>
              roomie<span className="brand-dot">.</span>
            </div>
            <button className="text-button" onClick={doLogout}>
              Log out
            </button>
          </div>
          <h1>Set up your profile.</h1>
          <p className="auth-sub">Signed in as @{user}. You can edit this anytime in My profile.</p>
          <ProfileForm
            profile={read(`roomie-profile:${user}`, { ...defaultProfile, name: "", school: "", major: "", bio: "" })}
            onSave={(p) => {
              save(`roomie-profile:${user}`, p);
              save(`roomie-ready:${user}`, true);
              setReady(true);
            }}
          />
        </section>
      </div>
    );
  return <App key={user} user={user} onLogout={doLogout} />;
}
function Root() {
  const [demo, setDemo] = useState(() => !isSupabaseConfigured || read("roomie-demo-mode", false));
  if (!isSupabaseConfigured) return <BasicRoot />;
  if (demo)
    return (
      <App
        onExit={() => {
          save("roomie-demo-mode", false);
          setDemo(false);
        }}
      />
    );
  return (
    <RealApp
      onDemo={() => {
        save("roomie-demo-mode", true);
        setDemo(true);
      }}
    />
  );
}
createRoot(document.getElementById("root")).render(<Root />);
