import { test } from "node:test";
import assert from "node:assert/strict";
import { fitUsers, userBreakdown, rankUsers, explainUsers } from "./scenarios.js";

const all = (action) =>
  ["dishes", "late", "friends", "cat", "morning", "tidy", "quiet", "dog", "counter", "weekend"].map((id) => ({ id, action }));

test("identical answers and budgets score 100", () => {
  assert.equal(fitUsers({ budget: 1000, answers: all("right") }, { budget: 1000, answers: all("right") }), 100);
});
test("opposite answers score lower than identical answers", () => {
  const me = { budget: 1000, answers: all("right") };
  assert.ok(fitUsers(me, { budget: 1000, answers: all("left") }) < fitUsers(me, { budget: 1000, answers: all("right") }));
});
test("missing answers are excluded and labeled, not guessed", () => {
  const rows = userBreakdown({ budget: 1000, answers: all("right") }, { budget: 1000, answers: [] });
  assert.equal(rows.filter((r) => r.value === null).length, 4);
  assert.equal(fitUsers({ budget: 1000, answers: all("right") }, { budget: 1000, answers: [] }), 100, "only budget counts");
  assert.equal(fitUsers({ answers: [] }, { answers: [] }), null, "no evidence at all → no score");
  assert.match(explainUsers({ budget: 1000, answers: all("right") }, { budget: 1000, answers: [] }), /Not counted/);
});
test("a dealbreaker weighs a dimension 3x", () => {
  const me = { budget: 1000, answers: [{ id: "friends", action: "up" }, { id: "dishes", action: "right" }] };
  const rows = userBreakdown(me, { budget: 1000, answers: [{ id: "friends", action: "right" }, { id: "dishes", action: "right" }] });
  assert.equal(rows.find((r) => r.key === "guests").weight, 3);
  assert.equal(rows.find((r) => r.key === "clean").weight, 1);
});
test("ranking recalculates when my answers change", () => {
  const others = [
    { id: "social", budget: 1000, answers: all("right") },
    { id: "quiet", budget: 1000, answers: all("left") },
  ];
  assert.equal(rankUsers({ budget: 1000, answers: all("right") }, others)[0].id, "social");
  assert.equal(rankUsers({ budget: 1000, answers: all("left") }, others)[0].id, "quiet");
});
