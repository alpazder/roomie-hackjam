// Hard-coded responses used whenever Gemini is unavailable (no key, timeout,
// error, or a static host like GitHub Pages with no server). They are built
// from the profile data only and are always labeled as not AI-generated.

const first = (name) => String(name || "your match").trim().split(/\s+/)[0];

const labels = {
  clean: (v) => (v >= 2 ? "a very tidy home" : v >= 1 ? "a pretty tidy home" : "a relaxed approach to cleaning"),
  sleep: (v) => (v === "Night owl" ? "late nights" : "early mornings"),
  guests: (v) => (v === "Often" ? "having friends over often" : v === "Sometimes" ? "guests sometimes" : "a quiet home with few guests"),
  pets: (v) => (v === "Pet friendly" ? "being pet friendly" : "a pet-free place"),
};

export function fallbackExplain(me = {}, profile = {}) {
  const name = first(profile.name);
  const strengths = [];
  if (Number.isFinite(me.budget) && Number.isFinite(profile.budget) && Math.abs(me.budget - profile.budget) <= 200)
    strengths.push(`Budgets are close ($${me.budget} vs $${profile.budget}/mo)`);
  if (profile.sleep) strengths.push(`${name} prefers ${labels.sleep(profile.sleep)}`);
  if (Number.isFinite(profile.clean)) strengths.push(`${name} likes ${labels.clean(profile.clean)}`);
  if (profile.major) strengths.push(`You can swap study tips with a ${profile.major} student`);
  while (strengths.length < 3) strengths.push("You both answered the same real-life scenarios");
  return {
    strengths: strengths.slice(0, 3),
    friction: {
      topic: "Guests",
      detail: `${name} prefers ${labels.guests(profile.guests)}. Make sure that fits your week.`,
      suggestion: "Agree on a guest heads-up rule (for example, a text before anyone stays over).",
    },
    icebreaker: `Hey ${name}! What does your ideal weeknight at home look like?`,
  };
}

export function fallbackAgreement(me = {}, profile = {}, friction) {
  const a = first(me.name) || "Roommate A";
  const b = first(profile.name);
  const f = friction?.topic ? `\n\n**About ${friction.topic.toLowerCase()}:** ${friction.suggestion || "Talk it through and write down what you agree on."}` : "";
  return `## Roommate agreement: ${a} & ${b}

**Quiet hours:** 11 pm–7 am on weeknights, midnight on weekends. Headphones after that.

**Guests:** Text each other before anyone comes over. Overnight guests at most two nights a week.

**Cleaning & chores:** Weekly rotation for bathroom, kitchen and trash. Dishes done within 24 hours.

**Kitchen:** Label personal food. Shared basics (oil, salt, paper towels) split evenly.

**Bills:** Rent and utilities split 50/50, paid by the 1st through an app you both use.

**Disagreements:** Bring it up within a day, in person, calmly. Check in on this agreement after one month.${f}`;
}

export function fallbackChatReply(profile = {}, messages = []) {
  const name = first(profile.name);
  const last = String(messages.filter((m) => m.role === "user").at(-1)?.text || "").toLowerCase();
  if (/rent|budget|\$|price|cost/.test(last))
    return `I'm aiming for around $${profile.budget || 1000}/mo. What range works for you?`;
  if (/clean|dish|chore|mess/.test(last))
    return "I like a clean kitchen. A simple chore rotation would work great for me.";
  if (/guest|friend|party|people over/.test(last))
    return "Friends over sometimes is fine with me, as long as we give each other a heads-up.";
  if (/sleep|night|morning|wake/.test(last))
    return profile.sleep === "Night owl" ? "I'm definitely more of a night owl 😅 but I keep it quiet." : "I'm an early riser, so quiet nights matter to me.";
  if (/^(hi|hey|hello|yo)\b/.test(last)) return `Hey! Nice to match with you 😊 What are you looking for in a roommate?`;
  return `That sounds good! Want to compare move-in dates next? — ${name}`;
}
