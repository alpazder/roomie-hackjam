import React, { useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  Sparkles,
} from "lucide-react";
import { scenarios, actions, infer, dimensions, rank, fit } from "./scenarios";
export default function ScenarioLab({
  answers,
  onAnswers,
  profile,
  people,
  onExplore,
  exploreLabel = "Explore profiles",
  completeLabel = "Meet your potential roomies",
  lockExploreUntilDone = false,
}) {
  const [drag, setDrag] = useState({ x: 0, y: 0 }),
    [leaving, setLeaving] = useState(""),
    [notice, setNotice] = useState(
      "Swipe a scenario to see your ranking change.",
    );
  const start = useRef(null),
    locked = useRef(false);
  const card = scenarios.find((s) => !answers.some((a) => a.id === s.id));
  const learned = infer(answers),
    sorted = rank(profile, people, answers);
  function choose(action) {
    if (!card || locked.current) return;
    locked.current = true;
    setLeaving(action);
    const old = sorted[0];
    setTimeout(() => {
      const next = [...answers, { id: card.id, action }];
      const top = rank(profile, people, next)[0];
      onAnswers(next);
      setNotice(
        top
          ? `${actions[action].short}: ${card.title} ${top.name} is now ranked #1${old && old.id !== top.id ? `, ahead of ${old.name}` : ""}.`
          : `${actions[action].short}: ${card.title} Saved.`,
      );
      setLeaving("");
      setDrag({ x: 0, y: 0 });
      locked.current = false;
    }, 220);
  }
  function release() {
    if (Math.max(Math.abs(drag.x), Math.abs(drag.y)) > 55) {
      choose(
        Math.abs(drag.x) > Math.abs(drag.y)
          ? drag.x > 0
            ? "right"
            : "left"
          : drag.y < 0
            ? "up"
            : "down",
      );
    }
    setDrag({ x: 0, y: 0 });
    start.current = null;
  }
  return (
    <div className="lab-layout">
      <section className="scenario-stage">
        <div className="scenario-progress">
          <b>
            {answers.length} / {scenarios.length} moments explored
          </b>
          <span>Four directions. Your everyday life.</span>
        </div>
        <div className="progress-track">
          <i
            style={{ width: (answers.length / scenarios.length) * 100 + "%" }}
          />
        </div>
        {card ? (
          <>
            <div className="direction-label">
              <ArrowUp size={15} /> Dealbreaker
            </div>
            <article
              tabIndex="0"
              aria-label={`Scenario: ${card.title}`}
              className={`scenario-card exit-${leaving}`}
              style={{
                transform: `translate(${drag.x}px,${drag.y}px) rotate(${drag.x / 25}deg)`,
              }}
              onKeyDown={(e) => {
                const map = {
                  ArrowLeft: "left",
                  ArrowRight: "right",
                  ArrowUp: "up",
                  ArrowDown: "down",
                };
                if (map[e.key]) {
                  e.preventDefault();
                  choose(map[e.key]);
                }
              }}
              onPointerDown={(e) => {
                start.current = { x: e.clientX, y: e.clientY };
                e.currentTarget.setPointerCapture(e.pointerId);
              }}
              onPointerMove={(e) => {
                if (start.current)
                  setDrag({
                    x: e.clientX - start.current.x,
                    y: e.clientY - start.current.y,
                  });
              }}
              onPointerUp={release}
              onPointerCancel={() => {
                start.current = null;
                setDrag({ x: 0, y: 0 });
              }}
            >
              <div className="eyebrow">
                A MOMENT AT HOME · {dimensions[card.dimension].toUpperCase()}
              </div>
              <div className="scenario-emoji">{card.emoji}</div>
              <h2>{card.title}</h2>
              <p className="scenario-text">{card.text}</p>
              <p className="scenario-context">{card.context}</p>
              <div className="scenario-sticker">
                How would that work for you?
              </div>
            </article>
            <div className="scenario-actions">
              {[
                ["left", ArrowLeft],
                ["up", ArrowUp],
                ["down", ArrowDown],
                ["right", ArrowRight],
              ].map(([key, Icon]) => (
                <button
                  key={key}
                  onClick={() => choose(key)}
                  className={"scenario-action " + key}
                >
                  <Icon size={21} />
                  <span>{actions[key].label}</span>
                </button>
              ))}
            </div>
            <p className="form-note">
              Drag in any direction, tap a choice, or focus the card and use
              arrow keys.
            </p>
          </>
        ) : (
          <div className="scenario-card complete">
            <Sparkles size={42} />
            <h2>Your rhythm, discovered.</h2>
            <p>
              You’ve explored all ten scenarios. Your discovery order now
              reflects those choices.
            </p>
            <button className="primary" onClick={onExplore}>
              {completeLabel}
            </button>
          </div>
        )}
        <div className="scenario-tools">
          <button
            className="text-button"
            disabled={!answers.length || !!leaving}
            onClick={() => onAnswers(answers.slice(0, -1))}
          >
            <RotateCcw size={15} />
            Undo last answer
          </button>
          <button
            className="text-button"
            disabled={!answers.length || !!leaving}
            onClick={() => {
              onAnswers([]);
              setNotice(
                "Answers cleared. All lifestyle dimensions are unlearned again.",
              );
            }}
          >
            Start over
          </button>
        </div>
      </section>
      <aside className="learning-panel">
        <div className="eyebrow">CHANGING WITH YOUR CHOICES</div>
        <h2>Your living fingerprint</h2>
        <p>
          These are estimates from scenario choices—not a personality test or an
          AI model.
        </p>
        <div className="fingerprint">
          {Object.entries(learned).map(([key, d]) => (
            <div key={key}>
              <span>
                {dimensions[key]}
                <small>
                  {d.evidence
                    ? `${d.evidence} answer${d.evidence > 1 ? "s" : ""}${d.hard ? " · strong priority" : ""}`
                    : "Not explored yet"}
                </small>
              </span>
              <div className="meter">
                <i style={{ width: d.evidence ? d.value * 100 + "%" : "0%" }} />
              </div>
            </div>
          ))}
        </div>
        {people.length > 0 && (
          <>
            <div className="rank-title">
              <b>Live roommate ranking</b>
              <span>
                {answers.length ? "Early estimate" : "Awaiting scenarios"}
              </span>
            </div>
            <div className="live-ranking">
              {sorted.map((p, i) => (
                <div key={p.id}>
                  <span className="rank-number">{i + 1}</span>
                  <span className="rank-name">
                    {p.name}
                    <small>{p.major}</small>
                  </span>
                  <b>{answers.length ? `${fit(profile, p, answers)}%` : "—"}</b>
                </div>
              ))}
            </div>
          </>
        )}
        <p className="ranking-status" aria-live="polite" role="status">
          {notice}
        </p>
        {(!lockExploreUntilDone || !card) && (
          <button className="primary" onClick={onExplore}>
            {exploreLabel}
          </button>
        )}
        <p className="form-note">
          Scores measure sample preference similarity, not the likelihood of a
          successful shared home. More answers improve coverage, not certainty.
        </p>
      </aside>
    </div>
  );
}
