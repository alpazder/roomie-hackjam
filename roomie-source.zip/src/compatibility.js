export function breakdown(a, b) {
  return [
    {
      label: "Budget",
      value: Math.max(0, 100 - Math.abs(a.budget - b.budget) / 8),
      detail: `$${b.budget}/month`,
    },
    {
      label: "Cleanliness",
      value: 100 - Math.abs(a.clean - b.clean) * 25,
      detail: ["Relaxed", "Pretty tidy", "Very tidy"][b.clean],
    },
    {
      label: "Sleep schedule",
      value: a.sleep === b.sleep ? 100 : 45,
      detail: b.sleep,
    },
    {
      label: "Guests",
      value: a.guests === b.guests ? 100 : 50,
      detail: b.guests,
    },
    { label: "Pets", value: a.pets === b.pets ? 100 : 40, detail: b.pets },
  ].map((x) => ({ ...x, value: Math.round(x.value) }));
}
export function score(a, b) {
  return Math.round(breakdown(a, b).reduce((s, x) => s + x.value, 0) / 5);
}
export function explain(a, b) {
  const rows = breakdown(a, b);
  const strengths = rows
    .filter((x) => x.value >= 80)
    .map((x) => x.label.toLowerCase());
  const trade = rows
    .filter((x) => x.value < 80)
    .map((x) => x.label.toLowerCase());
  return `${strengths.length ? `You align on ${strengths.join(", ")}.` : "You bring different routines to the table."} ${trade.length ? `Before moving in, talk about ${trade.join(" and ")} to set expectations.` : "Your everyday preferences look closely aligned. Try a coffee chat to see if you click!"} Recommendations use your questionnaire, not AI.`;
}
