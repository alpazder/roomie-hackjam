import { test } from "node:test";
import assert from "node:assert/strict";
import { infer, rank, fit, scenarioBreakdown } from "./scenarios.js";
const defaultProfile = { budget: 1100 };
const people = [
  {
    id: "abrey",
    name: "Abrey Biscardi",
    budget: 950,
    clean: 2,
    sleep: "Early bird",
    guests: "Rarely",
    pets: "No pets",
  },
  {
    id: "alex-nguyen",
    name: "Alex Nguyen",
    budget: 1250,
    clean: 1,
    sleep: "Night owl",
    guests: "Often",
    pets: "Pet friendly",
  },
  {
    id: "jack",
    name: "Jack Adelmann",
    budget: 1050,
    clean: 0,
    sleep: "Night owl",
    guests: "Sometimes",
    pets: "No pets",
  },
  {
    id: "henry",
    name: "Henry Adepeko",
    budget: 1400,
    clean: 2,
    sleep: "Early bird",
    guests: "Sometimes",
    pets: "Pet friendly",
  },
];
test("no lifestyle evidence is inferred before a swipe", () => {
  for (const d of Object.values(infer([]))) {
    assert.equal(d.value, 0.5);
    assert.equal(d.evidence, 0);
  }
});
test("opposite reactions move a preference in opposite directions", () => {
  assert.ok(infer([{ id: "friends", action: "right" }]).guests.value > 0.5);
  assert.ok(infer([{ id: "friends", action: "left" }]).guests.value < 0.5);
});
test("up marks a stronger boundary than left", () => {
  const up = infer([{ id: "friends", action: "up" }]).guests,
    left = infer([{ id: "friends", action: "left" }]).guests;
  assert.ok(up.value < left.value);
  assert.equal(up.hard, true);
});
test("down records flexibility without pushing the preference", () =>
  assert.equal(infer([{ id: "friends", action: "down" }]).guests.value, 0.5));
test("new scenario evidence changes the live ranking", () => {
  const before = rank(defaultProfile, people, []);
  const after = rank(defaultProfile, people, [{ id: "friends", action: "up" }]);
  assert.notEqual(before[0].id, after[0].id);
  assert.equal(after[0].id, "abrey");
});
test("scores stay bounded and demo profiles do not force a perfect first match", () => {
  for (const action of ["left", "right", "up", "down"])
    for (const p of people) {
      const n = fit(defaultProfile, p, [{ id: "friends", action }]);
      assert.ok(n >= 0 && n <= 100);
      assert.notEqual(n, 100);
    }
});
test("unexplored dimensions are explicitly labeled", () =>
  assert.equal(
    scenarioBreakdown(defaultProfile, people[0], []).filter(
      (r) => r.detail === "Not explored yet",
    ).length,
    4,
  ));
test("undo recomputes the original model", () => {
  const a = [
    { id: "friends", action: "up" },
    { id: "cat", action: "right" },
  ];
  assert.deepEqual(
    infer(a.slice(0, -1)),
    infer([{ id: "friends", action: "up" }]),
  );
});
