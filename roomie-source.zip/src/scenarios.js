export const scenarios = [
  {
    id: "dishes",
    dimension: "clean",
    target: 0,
    emoji: "🍝",
    title: "The pasta-night aftermath.",
    text: "Your roommate leaves dinner dishes in the sink until the next evening.",
    context: "It’s a normal weekday. Nobody is sick or in a rush.",
  },
  {
    id: "late",
    dimension: "sleep",
    target: 1,
    emoji: "🎧",
    title: "One more episode?",
    text: "Your roommate is active in the shared living room after midnight.",
    context: "Think about your usual week, rather than a special occasion.",
  },
  {
    id: "friends",
    dimension: "guests",
    target: 1,
    emoji: "🍿",
    title: "Your place is the hangout.",
    text: "A few friends come over to the apartment several evenings a week.",
    context: "No big party. Just a regular social home.",
  },
  {
    id: "cat",
    dimension: "pets",
    target: 1,
    emoji: "🐈",
    title: "A tiny third roommate.",
    text: "Your roommate wants to bring a cat into the shared home.",
    context:
      "Think about comfort, allergies, lease rules, and shared responsibilities.",
  },
  {
    id: "morning",
    dimension: "sleep",
    target: 0,
    emoji: "🌅",
    title: "The 7 a.m. routine.",
    text: "Your roommate starts their day early, making breakfast in the shared kitchen.",
    context: "A normal morning at home, with ordinary kitchen noise.",
  },
  {
    id: "tidy",
    dimension: "clean",
    target: 1,
    emoji: "🧽",
    title: "The Sunday reset.",
    text: "You and your roommate agree to clean shared spaces on a fixed weekly schedule.",
    context: "Both people take a turn, even during a busy week.",
  },
  {
    id: "quiet",
    dimension: "guests",
    target: 0,
    emoji: "📚",
    title: "Home is a quiet zone.",
    text: "You agree to host guests rarely and usually meet friends elsewhere.",
    context: "This would be the everyday rhythm of your shared home.",
  },
  {
    id: "dog",
    dimension: "pets",
    target: 1,
    emoji: "🐕",
    title: "Paws in the hallway.",
    text: "Your roommate has a dog that spends time in the shared living room.",
    context: "The owner handles care; you still share the space.",
  },
  {
    id: "counter",
    dimension: "clean",
    target: 1,
    emoji: "☕",
    title: "Ready for the next person.",
    text: "Everyone wipes the counter and puts things away right after using the kitchen.",
    context: "This is a regular expectation rather than an occasional favor.",
  },
  {
    id: "weekend",
    dimension: "guests",
    target: 1,
    emoji: "🛋️",
    title: "The visiting friend.",
    text: "Your roommate asks to have a friend stay over for the weekend.",
    context: "They ask ahead of time. You can still set boundaries together.",
  },
];
export const actions = {
  left: { label: "Not for me", short: "No", weight: 1 },
  right: { label: "Works for me", short: "Yes", weight: 1 },
  up: { label: "Dealbreaker", short: "Hard no", weight: 3 },
  down: { label: "I’m flexible", short: "Flexible", weight: 0.25 },
};
export const dimensions = {
  clean: "Cleanliness",
  sleep: "Sleep routine",
  guests: "Guests",
  pets: "Pets",
};
export function infer(answers) {
  const result = {};
  for (const key of Object.keys(dimensions)) {
    const relevant = answers.filter(
      (a) => scenarios.find((s) => s.id === a.id)?.dimension === key,
    );
    let total = 1,
      value = 0.5;
    for (const a of relevant) {
      const s = scenarios.find((s) => s.id === a.id),
        w = actions[a.action]?.weight || 0;
      const target =
        a.action === "down"
          ? 0.5
          : a.action === "right"
            ? s.target
            : 1 - s.target;
      value += target * w;
      total += w;
    }
    result[key] = {
      value: value / total,
      evidence: relevant.length,
      weight: total,
      hard: relevant.some((a) => a.action === "up"),
    };
  }
  return result;
}
export function rank(profile, people, answers) {
  return [...people].sort(
    (a, b) =>
      fit(profile, b, answers) - fit(profile, a, answers) ||
      a.id.localeCompare(b.id),
  );
}
export function fit(profile, p, answers) {
  const learned = infer(answers);
  const vector = {
    clean: p.clean / 2,
    sleep: p.sleep === "Night owl" ? 1 : 0,
    guests: p.guests === "Often" ? 1 : p.guests === "Sometimes" ? 0.5 : 0,
    pets: p.pets === "Pet friendly" ? 1 : 0,
  };
  let total = 1,
    points = Math.max(0, 1 - Math.abs(profile.budget - p.budget) / 1000);
  for (const key of Object.keys(dimensions)) {
    if (!learned[key].evidence) continue;
    const w = learned[key].hard ? 3 : 1;
    points += (1 - Math.abs(learned[key].value - vector[key])) * w;
    total += w;
  }
  return Math.round((points / total) * 100);
}
export function scenarioBreakdown(profile, p, answers) {
  const learned = infer(answers),
    vector = {
      clean: p.clean / 2,
      sleep: p.sleep === "Night owl" ? 1 : 0,
      guests: p.guests === "Often" ? 1 : p.guests === "Sometimes" ? 0.5 : 0,
      pets: p.pets === "Pet friendly" ? 1 : 0,
    };
  return [
    {
      label: "Budget",
      value: Math.round(
        Math.max(0, 1 - Math.abs(profile.budget - p.budget) / 1000) * 100,
      ),
      detail: `Sample: $${p.budget}/mo`,
    },
    ...Object.keys(dimensions).map((key) => ({
      label: dimensions[key],
      value: learned[key].evidence
        ? Math.round((1 - Math.abs(learned[key].value - vector[key])) * 100)
        : 0,
      detail: learned[key].evidence
        ? `${learned[key].evidence} scenario answers${learned[key].hard ? " · weighted boundary" : ""}`
        : "Not explored yet",
    })),
  ];
}
export function scenarioExplanation(profile, p, answers) {
  if (!answers.length)
    return "Explore a few scenarios first. No lifestyle score is shown before you give us any evidence.";
  const rows = scenarioBreakdown(profile, p, answers).filter(
    (r) => r.detail !== "Not explored yet",
  );
  const strengths = rows
      .filter((r) => r.value >= 75)
      .map((r) => r.label.toLowerCase()),
    trade = rows.filter((r) => r.value < 75).map((r) => r.label.toLowerCase());
  return `Based on ${answers.length} scenario choices, ${strengths.length ? "your strongest alignments are " + strengths.join(", ") : "you have different everyday preferences"}. ${trade.length ? "Talk about " + trade.join(", ") + " before deciding to live together." : "Discuss real routines together before making a decision."} This is a transparent numerical estimate, not an AI judgment.`;
}

// ---------------------------------------------------------------------------
// Real-user compatibility: both people's scenario answers plus both budgets.
// A lifestyle dimension counts only when BOTH people answered at least one
// scenario for it; otherwise it is reported as missing, never guessed.
// Dimensions where either person marked a dealbreaker weigh 3x.
// This is preference similarity, not a validated prediction.
// ---------------------------------------------------------------------------
export function userBreakdown(me, them) {
  const a = infer(me.answers || []);
  const b = infer(them.answers || []);
  const rows = [];
  const hasBudgets = Number.isFinite(me.budget) && Number.isFinite(them.budget);
  rows.push({
    key: "budget",
    label: "Budget",
    value: hasBudgets
      ? Math.round(Math.max(0, 1 - Math.abs(me.budget - them.budget) / 1000) * 100)
      : null,
    weight: hasBudgets ? 1 : 0,
    detail: hasBudgets ? `$${them.budget}/mo vs your $${me.budget}/mo` : "Budget missing",
  });
  for (const key of Object.keys(dimensions)) {
    const both = a[key].evidence > 0 && b[key].evidence > 0;
    const hard = a[key].hard || b[key].hard;
    rows.push({
      key,
      label: dimensions[key],
      value: both ? Math.round((1 - Math.abs(a[key].value - b[key].value)) * 100) : null,
      weight: both ? (hard ? 3 : 1) : 0,
      detail: !both
        ? a[key].evidence
          ? "They haven’t answered these scenarios"
          : "You haven’t answered these scenarios"
        : hard
          ? "A dealbreaker for one of you · counts 3×"
          : `${a[key].evidence} of your answers · ${b[key].evidence} of theirs`,
    });
  }
  return rows;
}

export function fitUsers(me, them) {
  const rows = userBreakdown(me, them).filter((r) => r.weight > 0);
  const total = rows.reduce((s, r) => s + r.weight, 0);
  if (!total) return null;
  return Math.round(rows.reduce((s, r) => s + r.value * r.weight, 0) / total);
}

export function rankUsers(me, others) {
  return [...others]
    .map((p) => ({ ...p, fit: fitUsers(me, p) }))
    .sort((x, y) => (y.fit ?? -1) - (x.fit ?? -1) || String(x.id).localeCompare(String(y.id)));
}

export function explainUsers(me, them) {
  const rows = userBreakdown(me, them);
  const counted = rows.filter((r) => r.weight > 0);
  const missing = rows.filter((r) => r.weight === 0).map((r) => r.label.toLowerCase());
  const strong = counted.filter((r) => r.value >= 75).map((r) => r.label.toLowerCase());
  const talk = counted.filter((r) => r.value < 75).map((r) => r.label.toLowerCase());
  return [
    strong.length ? `You line up on ${strong.join(", ")}.` : "Your answers point to different routines.",
    talk.length ? `Talk about ${talk.join(", ")} before deciding to live together.` : "",
    missing.length ? `Not counted (missing answers): ${missing.join(", ")}.` : "",
    "This is a similarity estimate from both people’s scenario answers and budgets, not a prediction or an AI judgment.",
  ]
    .filter(Boolean)
    .join(" ");
}
