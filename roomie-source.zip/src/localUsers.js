// Accounts created with the basic login (same browser) become discoverable
// profiles for each other. Their lifestyle traits come from their own scenario
// answers, and likes between real accounts must be mutual to match.
import { infer } from "./scenarios";

function read(k, f) {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? f;
  } catch {
    return f;
  }
}
function save(k, v) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {}
}

export const localId = (username) => `user:${username}`;
export const isLocalId = (id) => typeof id === "string" && id.startsWith("user:");
const usernameOf = (id) => id.slice(5);

function traitsFromAnswers(answers) {
  const d = infer(answers || []);
  const v = (k) => (d[k].evidence ? d[k].value : 0.5);
  return {
    clean: Math.round(v("clean") * 2),
    sleep: v("sleep") >= 0.5 ? "Night owl" : "Early bird",
    guests: v("guests") > 0.66 ? "Often" : v("guests") > 0.33 ? "Sometimes" : "Rarely",
    pets: v("pets") >= 0.5 ? "Pet friendly" : "No pets",
  };
}

function initials(name) {
  return (
    String(name || "?")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w[0].toUpperCase())
      .join("") || "?"
  );
}

/** Every other account in this browser that has finished its profile. */
export function localPeople(me) {
  const users = read("roomie-basic-users", {});
  return Object.keys(users)
    .filter((u) => u !== me && read(`roomie-ready:${u}`, false))
    .map((u) => {
      const p = read(`roomie-profile:${u}`, {});
      const answers = read(`roomie-v2-scenarios:${u}`, []);
      const theirSwipes = read(`roomie-v2-swipes:${u}`, []);
      return {
        id: localId(u),
        local: true,
        username: u,
        name: p.name || u,
        age: p.age,
        school: p.school || "",
        major: p.major || "",
        bio: p.bio || "",
        budget: Number.isFinite(p.budget) ? p.budget : 1100,
        interests: [],
        photo: p.photo || null,
        photoPosition: "center",
        color: "#d9cef5",
        initial: initials(p.name || u),
        ...traitsFromAnswers(answers),
        likedYou: me ? theirSwipes.some((s) => s.id === localId(me) && s.like) : false,
      };
    });
}

/** Record a mutual match on the other account too, so they see it when they log in. */
export function addMatchForOther(otherId, me) {
  const key = `roomie-v2-matches:${usernameOf(otherId)}`;
  const list = read(key, []);
  if (!list.includes(localId(me))) save(key, [...list, localId(me)]);
}

export function removeMatchForOther(otherId, me) {
  const key = `roomie-v2-matches:${usernameOf(otherId)}`;
  save(
    key,
    read(key, []).filter((id) => id !== localId(me)),
  );
}
