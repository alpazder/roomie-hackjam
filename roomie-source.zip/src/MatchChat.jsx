import React, { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { ArrowLeft, Send, Sparkles, FileText, X, Copy, MessageCircle, Heart } from "lucide-react";
import { getExplain, getAgreement, getChatReply, providerLabel } from "./aiClient";

// ---------- storage (per signed-in user, keyed by profile.id) ----------
function read(k, f) {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? f;
  } catch {
    return f;
  }
}
function save(k, v) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {}
}
const ns = (user) => user || "guest";
const myLocalId = (user) => `user:${user}`;
// Sample profiles: AI chat, private to this account.
// Real accounts (same browser): one shared thread both people read.
export const threadKey = (user, p) =>
  p.local ? `roomie-dm:${[myLocalId(user), p.id].sort().join("|")}` : `roomie-chat:${ns(user)}:${p.id}`;
const explainKey = (user, id) => `roomie-explain:${ns(user)}:${id}`;
const seenKey = (user, id) => `roomie-chat-seen:${ns(user)}:${id}`;

export const loadThread = (user, p) => read(threadKey(user, p), []);
export function unreadCount(user, p) {
  const seen = read(seenKey(user, p.id), 0);
  const mine = p.local ? myLocalId(user) : "me";
  return loadThread(user, p).filter((m) => m.at > seen && m.from !== mine).length;
}

// ---------- the person objects sent to the API ----------
export function aiPerson(p) {
  return {
    name: p.name,
    age: p.age,
    year: p.year,
    university: p.school || p.university,
    major: p.major,
    bio: p.bio,
    tags: p.interests || p.tags || [],
    budget: p.budget,
    clean: p.clean,
    sleep: p.sleep,
    guests: p.guests,
    pets: p.pets,
  };
}

// ---------- match modal insights ----------
export function MatchInsights({ user, me, person, score, onReady }) {
  const [data, setData] = useState(() => read(explainKey(user, person.id), null));
  useEffect(() => {
    let live = true;
    if (data) {
      onReady?.(data);
      return;
    }
    getExplain(me, aiPerson(person), score).then((d) => {
      if (!live) return;
      save(explainKey(user, person.id), d);
      setData(d);
      onReady?.(d);
    });
    return () => {
      live = false;
    };
  }, [person.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!data)
    return (
      <div className="insights-box loading" role="status">
        <span className="typing">
          <i />
          <i />
          <i />
        </span>
        Writing your match breakdown…
      </div>
    );
  return (
    <div className="insights-box">
      <ul>
        {data.strengths.map((s) => (
          <li key={s}>✅ {s}</li>
        ))}
        <li>
          ⚠️ <b>{data.friction.topic}:</b> {data.friction.detail} <em>{data.friction.suggestion}</em>
        </li>
        <li>💬 “{data.icebreaker}”</li>
      </ul>
      <small className="ai-label">{providerLabel(data.provider)}</small>
    </div>
  );
}

// ---------- agreement ----------
function AgreementModal({ user, me, person, onClose }) {
  const [state, setState] = useState({ loading: true, markdown: "", provider: "" });
  const [copied, setCopied] = useState(false);
  useEffect(() => {
    let live = true;
    const cached = read(`roomie-agreement:${ns(user)}:${person.id}`, null);
    if (cached) return setState({ loading: false, ...cached });
    const ex = read(explainKey(user, person.id), null);
    getAgreement(me, aiPerson(person), ex?.friction).then((d) => {
      if (!live) return;
      const v = { markdown: d.markdown, provider: d.provider };
      if (d.provider === "Gemini") save(`roomie-agreement:${ns(user)}:${person.id}`, v);
      setState({ loading: false, ...v });
    });
    return () => {
      live = false;
    };
  }, [person.id]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="modal-backdrop isolate" onClick={onClose}>
      <section role="dialog" aria-modal="true" aria-label="Roommate agreement" className="modal agreement" onClick={(e) => e.stopPropagation()}>
        <button className="close" aria-label="Close dialog" onClick={onClose}>
          <X />
        </button>
        {state.loading ? (
          <div className="insights-box loading" role="status">
            <span className="typing">
              <i />
              <i />
              <i />
            </span>
            Drafting your roommate agreement…
          </div>
        ) : (
          <>
            <div className="agreement-body">
              <ReactMarkdown>{state.markdown}</ReactMarkdown>
            </div>
            <small className="ai-label">{providerLabel(state.provider)}. Talk it through together before you sign anything.</small>
            <button
              className="secondary"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(state.markdown);
                  setCopied(true);
                } catch {}
              }}
            >
              <Copy size={14} /> {copied ? "Copied" : "Copy agreement"}
            </button>
          </>
        )}
      </section>
    </div>
  );
}

// ---------- chat ----------
function ChatView({ user, me, person, Avatar, onBack, onDetails }) {
  const key = threadKey(user, person);
  const mine = person.local ? myLocalId(user) : "me";
  const [messages, setMessages] = useState(() => read(key, []));
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(false);
  const [agreement, setAgreement] = useState(false);
  const [icebreaker, setIcebreaker] = useState(() => read(explainKey(user, person.id), null)?.icebreaker || "");
  const listRef = useRef(null);

  const markSeen = () => save(seenKey(user, person.id), Date.now());
  useEffect(() => {
    markSeen();
    if (!icebreaker)
      getExplain(me, aiPerson(person), null).then((d) => {
        save(explainKey(user, person.id), d);
        setIcebreaker(d.icebreaker);
      });
    // Real accounts: pick up messages written from another tab of this browser.
    const onStorage = (e) => e.key === key && setMessages(read(key, []));
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
    markSeen();
  }, [messages, typing]); // eslint-disable-line react-hooks/exhaustive-deps

  async function send(text) {
    const body = text.trim();
    if (!body || typing) return;
    const next = [...read(key, []), { from: mine, text: body, at: Date.now() }];
    save(key, next);
    setMessages(next);
    setDraft("");
    if (person.local) return; // real person: they'll reply when they log in
    setTyping(true);
    const history = next.map((m) => ({ role: m.from === "me" ? "user" : "assistant", text: m.text }));
    const started = Date.now();
    const d = await getChatReply(me, aiPerson(person), history);
    await new Promise((r) => setTimeout(r, Math.max(0, 700 - (Date.now() - started)))); // feel natural
    const withReply = [...read(key, []), { from: person.id, text: d.reply, at: Date.now(), provider: d.provider }];
    save(key, withReply);
    setMessages(withReply);
    setTyping(false);
  }

  return (
    <section className="chat" aria-label={`Conversation with ${person.name}`}>
      <header className="chat-header">
        <button className="icon-button" onClick={onBack} aria-label="Back to matches">
          <ArrowLeft size={18} />
        </button>
        <Avatar p={person} className="row-avatar" />
        <span className="row-main">
          <b>{person.name}</b>
          <small>{person.local ? `@${person.username} · real account in this browser` : "Sample profile · replies are AI-simulated"}</small>
        </span>
        <span className="chat-actions">
          {onDetails && (
            <button className="text-button" onClick={onDetails}>
              <Sparkles size={15} /> Fit
            </button>
          )}
          <button className="secondary" onClick={() => setAgreement(true)}>
            <FileText size={15} /> Roommate Agreement
          </button>
        </span>
      </header>
      <div className="chat-messages" ref={listRef}>
        {!messages.length && (
          <div className="chat-empty-box">
            <p className="chat-empty">You matched with {person.name.split(" ")[0]}! Say hi 👋</p>
            {icebreaker && (
              <button className="chip icebreaker" onClick={() => send(icebreaker)}>
                <Sparkles size={13} /> Send Icebreaker: “{icebreaker}”
              </button>
            )}
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={"bubble " + (m.from === mine ? "mine" : "theirs")}>
            <p>{m.text}</p>
            <small>
              {new Date(m.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
              {m.from !== mine && m.provider ? ` · ${m.provider === "Gemini" ? "AI reply" : "auto reply"}` : ""}
            </small>
          </div>
        ))}
        {typing && (
          <div className="bubble theirs typing-bubble" aria-label={`${person.name} is typing`}>
            <span className="typing">
              <i />
              <i />
              <i />
            </span>
          </div>
        )}
      </div>
      <form
        className="chat-composer"
        onSubmit={(e) => {
          e.preventDefault();
          send(draft);
        }}
      >
        <textarea
          rows={1}
          maxLength={500}
          placeholder={`Message ${person.name.split(" ")[0]}…`}
          value={draft}
          aria-label="Message"
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(draft);
            }
          }}
        />
        <button className="primary" type="submit" disabled={!draft.trim() || typing} aria-label="Send message">
          <Send size={17} />
        </button>
      </form>
      {person.local && <p className="form-note chat-note">Real account: {person.name.split(" ")[0]} sees this when they log in on this browser.</p>}
      {agreement && <AgreementModal user={user} me={me} person={person} onClose={() => setAgreement(false)} />}
    </section>
  );
}

// ---------- matches list + chat ----------
export function MatchesView({ user, me, matchedPeople, fitFor, chatWith, setChatWith, Avatar, onDetails, onDiscover }) {
  const person = chatWith && matchedPeople.find((p) => p.id === chatWith);
  if (person)
    return (
      <ChatView
        key={person.id}
        user={user}
        me={me}
        person={person}
        Avatar={Avatar}
        onBack={() => setChatWith(null)}
        onDetails={() => onDetails(person)}
      />
    );
  if (!matchedPeople.length)
    return (
      <div className="empty-state">
        <Heart size={42} />
        <h2>Your people are out there.</h2>
        <p>Like a profile. If they’ve liked you too, you’ll match and can start chatting here.</p>
        <button className="primary" onClick={onDiscover}>
          Explore profiles
        </button>
      </div>
    );
  return (
    <>
      <div className="section-label">
        {matchedPeople.length} {matchedPeople.length === 1 ? "match" : "matches"}
      </div>
      <div className="conversation-list">
        {matchedPeople.map((p) => {
          const thread = loadThread(user, p);
          const last = thread.at(-1);
          const unread = unreadCount(user, p);
          const fit = fitFor(p);
          return (
            <button key={p.id} className="conversation-row" onClick={() => setChatWith(p.id)}>
              <Avatar p={p} className="row-avatar" />
              <span className="row-main">
                <b>
                  {p.name}
                  {fit != null && <em className="row-fit">{fit}% fit</em>}
                </b>
                <small>
                  {last
                    ? `${last.from === "me" || last.from === `user:${user}` ? "You: " : ""}${last.text}`
                    : "New match. Say hi!"}
                </small>
              </span>
              <span className="row-side">
                {last && <small>{new Date(last.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</small>}
                {unread > 0 ? <b className="badge">{unread}</b> : <MessageCircle size={16} />}
              </span>
            </button>
          );
        })}
      </div>
    </>
  );
}
