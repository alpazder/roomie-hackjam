import jackPhoto from '../photos/IMG_7817.jpg';
import alexPhoto from '../photos/IMG_7818.jpg';
import abreyPhoto from '../photos/IMG_7819.jpg';
import henryPhoto from '../photos/IMG_7816.jpg';
export const photos={abrey:abreyPhoto,'alex-nguyen':alexPhoto,jack:jackPhoto,henry:henryPhoto};
