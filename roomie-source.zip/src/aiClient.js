// Browser side of the Gemini features. Calls the serverless routes in /api
// (same site on Vercel, or VITE_API_BASE when the frontend is hosted elsewhere).
// Never throws: if the server is missing (e.g. GitHub Pages), slow, or errors,
// it returns the same hard-coded fallback the server would, labeled "fallback".
import { fallbackExplain, fallbackAgreement, fallbackChatReply } from "./aiFallbacks";

const BASE = (import.meta.env.VITE_API_BASE || "").replace(/\/$/, "");

async function post(path, body, fallback) {
  try {
    const res = await fetch(`${BASE}/api/${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10000),
    });
    if (!(res.headers.get("content-type") || "").includes("application/json")) throw new Error("No API here");
    const data = await res.json();
    if (!res.ok || data.error) throw new Error(data.error || "API error");
    return data;
  } catch {
    return { ...fallback(), provider: "fallback" };
  }
}

export const getExplain = (me, profile, score) =>
  post("explain", { me, profile, score }, () => fallbackExplain(me, profile)).then((d) =>
    d.strengths && d.friction && d.icebreaker ? d : { ...fallbackExplain(me, profile), provider: "fallback" },
  );

export const getAgreement = (me, profile, friction) =>
  post("agreement", { me, profile, friction }, () => ({ markdown: fallbackAgreement(me, profile, friction) }));

export const getChatReply = (me, profile, messages) =>
  post("chat", { me, profile, messages: messages.slice(-12) }, () => ({ reply: fallbackChatReply(profile, messages) }));

export const providerLabel = (p) => (p === "Gemini" ? "Written by Gemini" : "Offline sample · Gemini not connected");
