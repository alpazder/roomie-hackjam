// Super-basic demo login: accounts live in this browser's localStorage.
// No encryption or real security. Used only when Supabase isn't configured.
import React, { useState } from "react";
import { House } from "lucide-react";

const USERS = "roomie-basic-users";
const SESSION = "roomie-basic-session";

function read(k, f) {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? f;
  } catch {
    return f;
  }
}
function save(k, v) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
    return true;
  } catch {
    return false;
  }
}
const STORAGE_BLOCKED =
  "This browser is blocking saved data (private/incognito window or an embedded page), so accounts can’t be saved. Open the site in a normal browser window.";

export const currentUser = () => {
  const u = read(SESSION, null);
  return u && read(USERS, {})[u] ? u : null;
};
export const logout = () => {
  try {
    localStorage.removeItem(SESSION);
  } catch {}
};

export default function BasicAuth({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function submit(e) {
    e.preventDefault();
    const name = username.trim().toLowerCase();
    const users = read(USERS, {});
    if (!name || !password) return setError("Enter a username and password.");
    if (mode === "signup") {
      if (users[name]) return setError(`“${name}” already has an account in this browser. Use Log in instead.`);
      users[name] = { password, createdAt: Date.now() };
      if (!save(USERS, users)) return setError(STORAGE_BLOCKED);
    } else if (!users[name]) {
      return setError(
        `No account called “${name}” in this browser yet. Tap Sign up to create one. Accounts are saved per browser, so one made on another device or browser won’t be here.`,
      );
    } else if (users[name].password !== password) {
      return setError("Wrong password for that account.");
    }
    if (!save(SESSION, name)) return setError(STORAGE_BLOCKED);
    onLogin(name);
  }

  return (
    <div className="auth-page">
      <section className="auth-card">
        <div className="auth-brand">
          <span className="brand-icon">
            <House size={23} />
          </span>
          roomie<span className="brand-dot">.</span>
        </div>
        <h1>{mode === "login" ? "Welcome back." : "Create your account."}</h1>
        <p className="auth-sub">Swipe real-life scenarios and find a roommate who lives like you.</p>
        <div className="auth-tabs" role="tablist">
          {[
            ["login", "Log in"],
            ["signup", "Sign up"],
          ].map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={mode === id}
              className={mode === id ? "active" : ""}
              onClick={() => {
                setMode(id);
                setError("");
              }}
            >
              {label}
            </button>
          ))}
        </div>
        <form className="auth-form" onSubmit={submit}>
          <label>
            Username or email
            <input autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
          </label>
          <label>
            Password
            <input
              type="password"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          {error && (
            <p className="auth-error" role="alert">
              {error}
            </p>
          )}
          <button className="primary" type="submit">
            {mode === "login" ? "Log in" : "Create account"}
          </button>
        </form>
        <p className="form-note">Demo login: accounts are saved only in this browser and aren’t secure. Don’t use a real password.</p>
      </section>
    </div>
  );
}
