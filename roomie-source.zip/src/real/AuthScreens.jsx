import React, { useState } from "react";
import { House, Sparkles } from "lucide-react";
import { signUp, logIn, requestPasswordReset, setNewPassword, friendlyError } from "./api";
import { Stepper, OfflineBanner } from "./common";

export function Brand() {
  return (
    <div className="auth-brand">
      <span className="brand-icon">
        <House size={23} />
      </span>
      roomie<span className="brand-dot">.</span>
    </div>
  );
}

export function AuthScreen({ onDemo }) {
  const [mode, setMode] = useState("login"); // login | signup | reset | sent | confirm
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (mode === "login") await logIn(email.trim(), password);
      else if (mode === "signup") {
        const data = await signUp(email.trim(), password);
        if (!data.session) setMode("confirm");
      } else if (mode === "reset") {
        await requestPasswordReset(email.trim());
        setMode("sent");
      }
    } catch (err) {
      setError(friendlyError(err));
    } finally {
      setBusy(false);
    }
  }

  const titles = {
    login: "Welcome back.",
    signup: "Let’s find your roommate.",
    reset: "Reset your password.",
    sent: "Check your email.",
    confirm: "Confirm your email.",
  };

  return (
    <div className="auth-page">
      <OfflineBanner />
      <section className="auth-card">
        <Brand />
        {mode === "signup" && <Stepper current={0} />}
        <h1>{titles[mode]}</h1>
        {mode === "sent" || mode === "confirm" ? (
          <>
            <p className="auth-sub">
              {mode === "sent"
                ? `If an account exists for ${email}, we sent a link to reset your password.`
                : `We sent a confirmation link to ${email}. Open it on this device to continue setting up your profile.`}
            </p>
            <button className="primary" onClick={() => setMode("login")}>
              Back to log in
            </button>
          </>
        ) : (
          <>
            <p className="auth-sub">
              {mode === "reset"
                ? "Enter your account email and we’ll send you a reset link."
                : "Swipe real-life scenarios, match with roommates who live like you, then chat."}
            </p>
            {mode !== "reset" && (
              <div className="auth-tabs" role="tablist">
                {[
                  ["login", "Log in"],
                  ["signup", "Sign up"],
                ].map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={mode === id}
                    className={mode === id ? "active" : ""}
                    onClick={() => {
                      setMode(id);
                      setError("");
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
            <form className="auth-form" onSubmit={submit}>
              <label>
                Email
                <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </label>
              {mode !== "reset" && (
                <label>
                  Password
                  <input
                    type="password"
                    required
                    minLength={8}
                    autoComplete={mode === "login" ? "current-password" : "new-password"}
                    placeholder={mode === "signup" ? "At least 8 characters" : ""}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </label>
              )}
              {error && (
                <p className="auth-error" role="alert">
                  {error}
                </p>
              )}
              <button className="primary" type="submit" disabled={busy}>
                {busy ? "Please wait…" : mode === "login" ? "Log in" : mode === "signup" ? "Create account" : "Send reset link"}
              </button>
            </form>
            <div className="auth-links">
              {mode === "login" && (
                <button type="button" className="text-button" onClick={() => setMode("reset")}>
                  Forgot password?
                </button>
              )}
              {mode === "reset" && (
                <button type="button" className="text-button" onClick={() => setMode("login")}>
                  Back to log in
                </button>
              )}
            </div>
          </>
        )}
        {onDemo && (
          <div className="demo-entry">
            <span>Just looking?</span>
            <button type="button" className="text-button" onClick={onDemo}>
              <Sparkles size={14} /> Try demo mode (sample profiles, no account)
            </button>
          </div>
        )}
      </section>
    </div>
  );
}

export function NewPasswordScreen({ onDone }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <div className="auth-page">
      <section className="auth-card">
        <Brand />
        <h1>Choose a new password.</h1>
        <form
          className="auth-form"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              await setNewPassword(password);
              onDone();
            } catch (err) {
              setError(friendlyError(err));
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            New password
            <input type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>
          {error && (
            <p className="auth-error" role="alert">
              {error}
            </p>
          )}
          <button className="primary" type="submit" disabled={busy}>
            {busy ? "Saving…" : "Save new password"}
          </button>
        </form>
      </section>
    </div>
  );
}
