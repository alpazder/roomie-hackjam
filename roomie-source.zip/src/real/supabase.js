import { createClient } from "@supabase/supabase-js";

// Only the project URL and the PUBLISHABLE (anon) key belong in the frontend.
// Never put a service-role key, database password, or Gemini key here.
const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export const isSupabaseConfigured = Boolean(url && key);

export const supabase = isSupabaseConfigured
  ? createClient(url, key, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    })
  : null;

export const redirectUrl = () =>
  typeof window === "undefined" ? undefined : window.location.origin + window.location.pathname;
