// Data layer for real-user mode. Every privileged write goes through a
// database function that re-checks the signed-in user, so the UI never has
// the final say on matches, messages, or blocking.
import { supabase, redirectUrl } from "./supabase";

export const PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const PHOTO_MAX_BYTES = 3 * 1024 * 1024;
export const PAGE_SIZE = 30;

export function friendlyError(error) {
  if (!error) return "";
  if (typeof navigator !== "undefined" && navigator.onLine === false)
    return "You’re offline. Check your connection and try again.";
  const msg = error.message || String(error);
  if (/Failed to fetch|NetworkError|network/i.test(msg))
    return "Couldn’t reach the server. Check your connection and try again.";
  if (/Invalid login credentials/i.test(msg)) return "That email and password don’t match.";
  if (/Email not confirmed/i.test(msg)) return "Confirm your email first. Check your inbox for the link.";
  if (/User already registered/i.test(msg)) return "An account with that email already exists. Log in instead.";
  if (/JWT|session/i.test(msg)) return "Your session expired. Please log in again.";
  return msg;
}

async function must(promise) {
  const { data, error } = await promise;
  if (error) throw error;
  return data;
}

// ---- Auth -----------------------------------------------------------------
export const signUp = (email, password) =>
  must(supabase.auth.signUp({ email, password, options: { emailRedirectTo: redirectUrl() } }));
export const logIn = (email, password) => must(supabase.auth.signInWithPassword({ email, password }));
export const logOut = () => supabase.auth.signOut();
export const requestPasswordReset = (email) =>
  must(supabase.auth.resetPasswordForEmail(email, { redirectTo: redirectUrl() }));
export const setNewPassword = (password) => must(supabase.auth.updateUser({ password }));

// ---- Profile & answers ----------------------------------------------------
export const PROFILE_FIELDS =
  "id, display_name, university, major, bio, budget, preferred_city, move_in_date, interests, photo_path, discoverable, onboarding_step";

export const getMyProfile = (uid) =>
  must(supabase.from("profiles").select(PROFILE_FIELDS).eq("id", uid).single());

export const updateMyProfile = (uid, patch) =>
  must(supabase.from("profiles").update(patch).eq("id", uid).select(PROFILE_FIELDS).single());

export const getMyAnswers = async (uid) =>
  (await must(
    supabase.from("scenario_answers").select("scenario_id, action, answered_at").eq("user_id", uid).order("answered_at"),
  )).map((r) => ({ id: r.scenario_id, action: r.action }));

export const saveAnswer = (uid, id, action) =>
  must(
    supabase
      .from("scenario_answers")
      .upsert({ user_id: uid, scenario_id: id, action, answered_at: new Date().toISOString() }),
  );

export const deleteAnswers = (uid, ids) =>
  must(supabase.from("scenario_answers").delete().eq("user_id", uid).in("scenario_id", ids));

// ---- Photos ---------------------------------------------------------------
export function validatePhoto(file) {
  if (!file) return "Choose a photo.";
  if (!PHOTO_TYPES.includes(file.type)) return "Use a JPEG, PNG, or WebP image.";
  if (file.size > PHOTO_MAX_BYTES) return "Photos must be 3 MB or smaller.";
  return "";
}

// Re-encode in the browser: strips EXIF metadata (including GPS location)
// and downsizes large phone photos before upload.
async function reencode(file) {
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 1200 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, file.type, 0.88));
    return blob && blob.type === file.type ? new File([blob], "photo", { type: file.type }) : file;
  } catch {
    return file;
  }
}

export async function uploadPhoto(uid, original, oldPath) {
  const problem = validatePhoto(original);
  if (problem) throw new Error(problem);
  const file = await reencode(original);
  const ext = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" }[file.type];
  const path = `${uid}/${Date.now()}.${ext}`;
  await must(supabase.storage.from("avatars").upload(path, file, { contentType: file.type, upsert: false }));
  const profile = await updateMyProfile(uid, { photo_path: path });
  if (oldPath && oldPath !== path) supabase.storage.from("avatars").remove([oldPath]).catch(() => {});
  return profile;
}

export async function removePhoto(uid, oldPath) {
  const profile = await updateMyProfile(uid, { photo_path: null });
  if (oldPath) supabase.storage.from("avatars").remove([oldPath]).catch(() => {});
  return profile;
}

const urlCache = new Map();
export async function signedPhotoUrls(paths) {
  const now = Date.now();
  const need = [...new Set(paths.filter(Boolean))].filter((p) => !(urlCache.get(p)?.expires > now));
  if (need.length) {
    const data = await must(supabase.storage.from("avatars").createSignedUrls(need, 3600));
    for (const row of data) if (row.signedUrl) urlCache.set(row.path, { url: row.signedUrl, expires: now + 55 * 60 * 1000 });
  }
  return Object.fromEntries(paths.filter(Boolean).map((p) => [p, urlCache.get(p)?.url]));
}

// ---- Discovery & matching ---------------------------------------------------
export const discoverCandidates = () => must(supabase.rpc("discover_candidates"));
export const recordSwipe = (target, action) => must(supabase.rpc("record_swipe", { p_target: target, p_action: action }));
export const myMatches = () => must(supabase.rpc("my_matches"));
export const unmatch = (matchId) => must(supabase.rpc("unmatch", { p_match: matchId }));
export const blockUser = (userId) => must(supabase.rpc("block_user", { p_target: userId }));

// ---- Messages -------------------------------------------------------------
export async function loadMessages(matchId, before) {
  let q = supabase
    .from("messages")
    .select("id, match_id, sender_id, body, created_at")
    .eq("match_id", matchId)
    .order("created_at", { ascending: false })
    .order("id", { ascending: false })
    .limit(PAGE_SIZE);
  if (before) q = q.lt("created_at", before);
  const rows = await must(q);
  return { rows: rows.reverse(), hasMore: rows.length === PAGE_SIZE };
}

export const sendMessage = (id, matchId, body) =>
  must(supabase.rpc("send_message", { p_id: id, p_match: matchId, p_body: body }));

export const markRead = (matchId) => must(supabase.rpc("mark_read", { p_match: matchId }));

export function subscribeToMessages(onInsert, matchId) {
  const channel = supabase
    .channel(matchId ? `messages:${matchId}` : `messages:all:${Math.random().toString(36).slice(2)}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages", ...(matchId ? { filter: `match_id=eq.${matchId}` } : {}) },
      (payload) => onInsert(payload.new),
    )
    .subscribe();
  return () => supabase.removeChannel(channel);
}

export const newId = () =>
  globalThis.crypto?.randomUUID
    ? crypto.randomUUID()
    : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) =>
        (c ^ (Math.random() * 16) >> (c / 4)).toString(16),
      );
