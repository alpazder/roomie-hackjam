import React, { useState } from "react";
import ScenarioLab from "../ScenarioLab";
import { scenarios, actions, dimensions } from "../scenarios";
import { saveAnswer, deleteAnswers, updateMyProfile, friendlyError } from "./api";
import { ErrorNote } from "./common";

// Onboarding: the ten scenario cards, saved one answer at a time.
export function VibeOnboarding({ uid, profile, answers, setAnswers, onFinished }) {
  const [error, setError] = useState("");
  const [finishing, setFinishing] = useState(false);

  async function onAnswers(next) {
    const prev = answers;
    const prevIds = new Set(prev.map((a) => a.id));
    const nextIds = new Set(next.map((a) => a.id));
    const added = next.filter((a) => !prevIds.has(a.id));
    const removed = prev.filter((a) => !nextIds.has(a.id)).map((a) => a.id);
    setError("");
    setAnswers(next); // optimistic; reverted on failure
    try {
      for (const a of added) await saveAnswer(uid, a.id, a.action);
      if (removed.length) await deleteAnswers(uid, removed);
    } catch (err) {
      setAnswers(prev);
      setError(`That answer wasn’t saved. ${friendlyError(err)}`);
    }
  }

  async function finish() {
    setFinishing(true);
    setError("");
    try {
      const saved = await updateMyProfile(uid, { onboarding_step: "done" });
      onFinished(saved);
    } catch (err) {
      setError(friendlyError(err));
    } finally {
      setFinishing(false);
    }
  }

  return (
    <>
      <div className="vibe-intro">
        <p>
          React to each moment the way you would at home. <b>Left</b>: not for me · <b>Right</b>: works for me · <b>Up</b>: dealbreaker
          (counts 3× in compatibility) · <b>Down</b>: I’m flexible. Every answer saves as you go, so you can leave and resume later.
        </p>
      </div>
      <ErrorNote error={error} />
      <ScenarioLab
        answers={answers}
        onAnswers={onAnswers}
        profile={profile}
        people={[]}
        onExplore={finish}
        exploreLabel={finishing ? "Finishing…" : "Finish and start discovering"}
        completeLabel={finishing ? "Finishing…" : "Finish and start discovering"}
        lockExploreUntilDone
      />
    </>
  );
}

// After onboarding: revisit and change any answer. Rankings update immediately.
export function VibeReview({ uid, answers, setAnswers }) {
  const [error, setError] = useState("");
  const [saving, setSaving] = useState("");
  const current = Object.fromEntries(answers.map((a) => [a.id, a.action]));

  async function change(id, action) {
    if (current[id] === action) return;
    const prev = answers;
    const next = prev.some((a) => a.id === id) ? prev.map((a) => (a.id === id ? { id, action } : a)) : [...prev, { id, action }];
    setSaving(id);
    setError("");
    setAnswers(next);
    try {
      await saveAnswer(uid, id, action);
    } catch (err) {
      setAnswers(prev);
      setError(`Not saved. ${friendlyError(err)}`);
    } finally {
      setSaving("");
    }
  }

  return (
    <div className="vibe-review">
      <p className="form-note">
        Change any answer and your discovery ranking recalculates right away. Compatibility compares your answers with each person’s
        answers for the same lifestyle area (cleanliness, sleep, guests, pets) plus both budgets. Areas where either of you has a
        dealbreaker count three times as much. Areas either person hasn’t answered are left out, not guessed.
      </p>
      <ErrorNote error={error} />
      {scenarios.map((s) => (
        <div className="review-row" key={s.id}>
          <div className="review-text">
            <span className="review-emoji">{s.emoji}</span>
            <span>
              <b>{s.title}</b>
              <small>
                {dimensions[s.dimension]} · {s.text}
              </small>
            </span>
          </div>
          <div className="review-choices" role="radiogroup" aria-label={s.title}>
            {["left", "right", "up", "down"].map((k) => (
              <button
                key={k}
                type="button"
                role="radio"
                aria-checked={current[s.id] === k}
                disabled={saving === s.id}
                className={"chip" + (current[s.id] === k ? " active" : "") + (k === "up" ? " danger" : "")}
                onClick={() => change(s.id, k)}
              >
                {actions[k].label}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
