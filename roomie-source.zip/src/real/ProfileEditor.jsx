import React, { useRef, useState } from "react";
import { Camera, Check, Trash2, X } from "lucide-react";
import { updateMyProfile, uploadPhoto, removePhoto, validatePhoto, friendlyError, PHOTO_TYPES } from "./api";
import { UserAvatar, usePhotoUrls } from "./common";

const USF = "University of South Florida (USF)";
const UNIVERSITIES = [
  USF,
  "University of Tampa (UT)",
  "University of Central Florida (UCF)",
  "University of Florida (UF)",
  "Florida International University (FIU)",
  "Florida State University (FSU)",
  "Hillsborough College",
];

const REQUIRED = ["display_name", "university", "major", "budget", "preferred_city", "move_in_date"];

function Req() {
  return (
    <b className="req" aria-hidden="true">
      *
    </b>
  );
}
function Opt() {
  return <small className="optional">Optional</small>;
}

export default function ProfileEditor({ uid, profile, mode, onSaved }) {
  // mode: "onboarding" | "edit"
  const [d, setD] = useState(() => ({
    display_name: profile.display_name || "",
    university: profile.university || USF,
    major: profile.major || "",
    bio: profile.bio || "",
    budget: profile.budget ?? 1000,
    preferred_city: profile.preferred_city || "Tampa, FL",
    move_in_date: profile.move_in_date || "",
    interests: profile.interests || [],
    discoverable: profile.discoverable ?? true,
  }));
  const [interestDraft, setInterestDraft] = useState("");
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ busy: false, error: "", saved: false });
  const [photo, setPhoto] = useState({ busy: false, error: "" });
  const fileRef = useRef(null);
  const urls = usePhotoUrls([profile.photo_path]);
  const set = (k, v) => {
    setD((x) => ({ ...x, [k]: v }));
    setErrors((e) => ({ ...e, [k]: "" }));
    setStatus((s) => ({ ...s, saved: false, error: "" }));
  };

  function addInterest() {
    const parts = interestDraft
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!parts.length) return;
    const next = [...new Set([...d.interests, ...parts.map((p) => p.slice(0, 24))])].slice(0, 8);
    set("interests", next);
    setInterestDraft("");
  }

  function validate() {
    const e = {};
    for (const k of REQUIRED) if (d[k] === "" || d[k] === null || d[k] === undefined || String(d[k]).trim() === "") e[k] = "Required";
    if (d.budget < 300 || d.budget > 5000) e.budget = "Between $300 and $5,000";
    setErrors(e);
    return !Object.keys(e).length;
  }

  async function save(ev) {
    ev.preventDefault();
    if (!validate()) {
      setStatus({ busy: false, error: "Fill in the required fields marked with *.", saved: false });
      return;
    }
    setStatus({ busy: true, error: "", saved: false });
    try {
      const patch = {
        display_name: d.display_name.trim(),
        university: d.university.trim(),
        major: d.major.trim(),
        bio: d.bio.trim() || null,
        budget: Number(d.budget),
        preferred_city: d.preferred_city.trim(),
        move_in_date: d.move_in_date,
        interests: d.interests,
        discoverable: d.discoverable,
      };
      if (mode === "onboarding" && profile.onboarding_step === "profile") patch.onboarding_step = "vibe";
      const saved = await updateMyProfile(uid, patch);
      setStatus({ busy: false, error: "", saved: true });
      onSaved(saved);
    } catch (err) {
      setStatus({ busy: false, error: friendlyError(err), saved: false });
    }
  }

  async function pickPhoto(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const problem = validatePhoto(file);
    if (problem) return setPhoto({ busy: false, error: problem });
    setPhoto({ busy: true, error: "" });
    try {
      const saved = await uploadPhoto(uid, file, profile.photo_path);
      setPhoto({ busy: false, error: "" });
      onSaved(saved);
    } catch (err) {
      setPhoto({ busy: false, error: friendlyError(err) });
    }
  }

  async function dropPhoto() {
    setPhoto({ busy: true, error: "" });
    try {
      const saved = await removePhoto(uid, profile.photo_path);
      setPhoto({ busy: false, error: "" });
      onSaved(saved);
    } catch (err) {
      setPhoto({ busy: false, error: friendlyError(err) });
    }
  }

  const field = (k) => (errors[k] ? { "aria-invalid": true } : {});

  return (
    <form className="profile-editor" onSubmit={save} noValidate>
      <div className="photo-row">
        <UserAvatar name={d.display_name} url={urls[profile.photo_path]} className="editor-avatar" />
        <div>
          <b>
            Profile photo <Opt />
          </b>
          <p className="form-note">JPEG, PNG, or WebP up to 3 MB. Only signed-in users who can see your profile can view it.</p>
          <div className="photo-actions">
            <button type="button" className="secondary" disabled={photo.busy} onClick={() => fileRef.current?.click()}>
              <Camera size={15} /> {photo.busy ? "Uploading…" : profile.photo_path ? "Change photo" : "Upload photo"}
            </button>
            {profile.photo_path && (
              <button type="button" className="text-button" disabled={photo.busy} onClick={dropPhoto}>
                <Trash2 size={14} /> Remove
              </button>
            )}
          </div>
          <input ref={fileRef} type="file" accept={PHOTO_TYPES.join(",")} hidden onChange={pickPhoto} />
          {photo.error && (
            <p className="auth-error" role="alert">
              {photo.error}
            </p>
          )}
        </div>
      </div>

      <p className="form-note">
        <Req /> Required. Your email is never shown to other users.
      </p>
      <div className="form-grid">
        <label>
          <span>
            Display name <Req />
          </span>
          <input maxLength="40" value={d.display_name} onChange={(e) => set("display_name", e.target.value)} {...field("display_name")} />
          {errors.display_name && <em className="field-error">{errors.display_name}</em>}
        </label>
        <label>
          <span>
            Major <Req />
          </span>
          <input maxLength="80" placeholder="e.g. Computer Science" value={d.major} onChange={(e) => set("major", e.target.value)} {...field("major")} />
          {errors.major && <em className="field-error">{errors.major}</em>}
        </label>
        <label className="full">
          <span>
            University <Req />
          </span>
          <input maxLength="100" list="roomie-universities" value={d.university} onChange={(e) => set("university", e.target.value)} {...field("university")} />
          <datalist id="roomie-universities">
            {UNIVERSITIES.map((u) => (
              <option key={u} value={u} />
            ))}
          </datalist>
          {errors.university && <em className="field-error">{errors.university}</em>}
        </label>
        <label>
          <span>
            Preferred city <Req />
          </span>
          <input maxLength="80" value={d.preferred_city} onChange={(e) => set("preferred_city", e.target.value)} {...field("preferred_city")} />
          {errors.preferred_city && <em className="field-error">{errors.preferred_city}</em>}
        </label>
        <label>
          <span>
            Move-in date <Req />
          </span>
          <input type="date" value={d.move_in_date} onChange={(e) => set("move_in_date", e.target.value)} {...field("move_in_date")} />
          {errors.move_in_date && <em className="field-error">{errors.move_in_date}</em>}
        </label>
        <label className="full">
          <span>
            Monthly rent budget · ${Number(d.budget).toLocaleString()} <Req />
          </span>
          <input type="range" min="300" max="3000" step="50" value={d.budget} onChange={(e) => set("budget", +e.target.value)} />
          {errors.budget && <em className="field-error">{errors.budget}</em>}
        </label>
        <label className="full">
          <span>
            Interests <Opt />
          </span>
          <span className="interest-input">
            <input
              maxLength="60"
              placeholder="Type and press Enter, e.g. cooking, soccer"
              value={interestDraft}
              onChange={(e) => setInterestDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === ",") {
                  e.preventDefault();
                  addInterest();
                }
              }}
              onBlur={addInterest}
              disabled={d.interests.length >= 8}
            />
          </span>
          <span className="tags">
            {d.interests.map((t) => (
              <button type="button" key={t} className="tag-chip" onClick={() => set("interests", d.interests.filter((x) => x !== t))} aria-label={`Remove ${t}`}>
                {t} <X size={12} />
              </button>
            ))}
            <small className="form-note">{d.interests.length}/8</small>
          </span>
        </label>
        <label className="full">
          <span>
            A little about you <Opt />
          </span>
          <textarea maxLength="350" value={d.bio} onChange={(e) => set("bio", e.target.value)} />
        </label>
        {mode === "edit" && (
          <label className="full toggle-row">
            <input type="checkbox" checked={d.discoverable} onChange={(e) => set("discoverable", e.target.checked)} />
            <span>
              Show me in discovery
              <small>Turn off to stop appearing to new people. Existing matches and chats stay.</small>
            </span>
          </label>
        )}
      </div>
      {status.error && (
        <p className="auth-error" role="alert">
          {status.error}
        </p>
      )}
      <button className="primary save-profile" type="submit" disabled={status.busy}>
        {status.busy ? "Saving…" : mode === "onboarding" ? "Save and continue" : "Save profile"} <Check size={17} />
      </button>
      {status.saved && mode === "edit" && (
        <p className="form-note saved-note" role="status">
          Saved.
        </p>
      )}
    </form>
  );
}
