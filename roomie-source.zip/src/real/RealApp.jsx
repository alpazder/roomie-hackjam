import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { House, Heart, Compass, User, Sparkles, LogOut, ChevronRight } from "lucide-react";
import { supabase } from "./supabase";
import { getMyProfile, getMyAnswers, myMatches, subscribeToMessages, logOut, friendlyError } from "./api";
import { AuthScreen, NewPasswordScreen, Brand } from "./AuthScreens";
import ProfileEditor from "./ProfileEditor";
import { VibeOnboarding, VibeReview } from "./Vibe";
import Discover from "./Discover";
import Matches from "./Matches";
import Chat from "./Chat";
import { Stepper, Spinner, ErrorNote, OfflineBanner, usePhotoUrls, UserAvatar } from "./common";

export default function RealApp({ onDemo }) {
  const [session, setSession] = useState(undefined); // undefined = checking
  const [recovery, setRecovery] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session ?? null));
    const { data } = supabase.auth.onAuthStateChange((event, s) => {
      if (event === "PASSWORD_RECOVERY") setRecovery(true);
      setSession(s ?? null);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  if (session === undefined) return <Spinner label="Starting Roomie…" />;
  if (recovery && session) return <NewPasswordScreen onDone={() => setRecovery(false)} />;
  if (!session) return <AuthScreen onDemo={onDemo} />;
  return <SignedIn key={session.user.id} uid={session.user.id} email={session.user.email} />;
}

function SignedIn({ uid, email }) {
  const [profile, setProfile] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [loadError, setLoadError] = useState("");

  const load = useCallback(async () => {
    setLoadError("");
    try {
      const [p, a] = await Promise.all([getMyProfile(uid), getMyAnswers(uid)]);
      setProfile(p);
      setAnswers(a);
    } catch (err) {
      setLoadError(friendlyError(err));
    }
  }, [uid]);
  useEffect(() => {
    load();
  }, [load]);

  if (loadError)
    return (
      <div className="auth-page">
        <section className="auth-card">
          <Brand />
          <ErrorNote error={loadError} onRetry={load} />
          <button className="text-button" onClick={logOut}>
            Log out
          </button>
        </section>
      </div>
    );
  if (!profile) return <Spinner label="Loading your profile…" />;

  if (profile.onboarding_step !== "done")
    return (
      <div className="auth-page onboarding">
        <OfflineBanner />
        <section className={"auth-card " + (profile.onboarding_step === "vibe" ? "xwide" : "wide")}>
          <div className="onboarding-top">
            <Brand />
            <button className="text-button" onClick={logOut}>
              <LogOut size={14} /> Log out
            </button>
          </div>
          <Stepper current={profile.onboarding_step === "profile" ? 1 : 2} />
          {profile.onboarding_step === "profile" ? (
            <>
              <h1>Tell people about you.</h1>
              <p className="auth-sub">Signed in as {email}. Your email stays private.</p>
              <ProfileEditor uid={uid} profile={profile} mode="onboarding" onSaved={setProfile} />
            </>
          ) : (
            <>
              <div className="onboarding-head">
                <h1>Your vibe: 10 everyday moments.</h1>
                <button className="text-button" onClick={() => setProfile({ ...profile, onboarding_step: "profile" })}>
                  Edit profile details
                </button>
              </div>
              <VibeOnboarding uid={uid} profile={profile} answers={answers} setAnswers={setAnswers} onFinished={setProfile} />
            </>
          )}
        </section>
      </div>
    );

  return <Shell uid={uid} email={email} profile={profile} setProfile={setProfile} answers={answers} setAnswers={setAnswers} />;
}

function Shell({ uid, email, profile, setProfile, answers, setAnswers }) {
  const [page, setPage] = useState("discover");
  const [chatId, setChatId] = useState(null);
  const [matchState, setMatchState] = useState({ loading: true, error: "", list: [] });
  const photo = usePhotoUrls([profile.photo_path]);
  const me = useMemo(
    () => ({ id: uid, display_name: profile.display_name, budget: profile.budget, answers, photoUrl: photo[profile.photo_path] }),
    [uid, profile.display_name, profile.budget, answers, photo, profile.photo_path],
  );

  const refreshTimer = useRef(null);
  const loadMatches = useCallback(async () => {
    try {
      const list = await myMatches();
      setMatchState({ loading: false, error: "", list });
    } catch (err) {
      setMatchState((s) => ({ ...s, loading: false, error: friendlyError(err) }));
    }
  }, []);
  const refreshSoon = useCallback(() => {
    clearTimeout(refreshTimer.current);
    refreshTimer.current = setTimeout(loadMatches, 250);
  }, [loadMatches]);

  useEffect(() => {
    loadMatches();
    const stop = subscribeToMessages(() => refreshSoon());
    const onFocus = () => refreshSoon();
    window.addEventListener("focus", onFocus);
    return () => {
      stop();
      window.removeEventListener("focus", onFocus);
    };
  }, [loadMatches, refreshSoon]);

  const unread = matchState.list.reduce((n, m) => n + (m.unread_count || 0), 0);
  const chat = chatId && matchState.list.find((m) => m.match_id === chatId);

  function openChat(id) {
    setMatchState((s) => ({ ...s, loading: true }));
    setChatId(id);
    setPage("matches");
    loadMatches();
  }

  const titles = {
    discover: ["Good vibes. Great roommates.", "Ranked by how your scenario answers line up with theirs."],
    matches: ["A connection worth keeping.", "Mutual matches and your conversations."],
    vibe: ["Your vibe.", "Revisit your answers anytime. Rankings update right away."],
    profile: ["Make yourself at home.", "Edit your profile and choose whether you appear in discovery."],
  };

  return (
    <>
      <aside className="sidebar">
        <a className="brand" href="#" onClick={(e) => e.preventDefault()}>
          <span className="brand-icon">
            <House size={23} />
          </span>
          roomie<span className="brand-dot">.</span>
        </a>
        <div className="workspace-label">YOUR SPACE, YOUR PEOPLE</div>
        <nav>
          {[
            ["discover", Compass, "Discover"],
            ["matches", Heart, "Matches"],
            ["vibe", Sparkles, "Your vibe"],
            ["profile", User, "My profile"],
          ].map(([id, Icon, label]) => (
            <button
              key={id}
              className={page === id ? "nav active" : "nav"}
              onClick={() => {
                setPage(id);
                if (id !== "matches") setChatId(null);
              }}
            >
              <Icon size={21} />
              {label}
              {id === "matches" && unread > 0 && (
                <b className="badge" aria-label={`${unread} unread messages`}>
                  {unread}
                </b>
              )}
            </button>
          ))}
        </nav>
        <button className="account" onClick={() => setPage("profile")}>
          <UserAvatar name={profile.display_name} url={me.photoUrl} className="account-avatar" />
          <div>
            <b>{profile.display_name}</b>
            <small>{profile.discoverable ? "Visible in discovery" : "Hidden from discovery"}</small>
          </div>
          <ChevronRight size={16} />
        </button>
      </aside>
      <div className="main">
        <header>
          <div className="breadcrumb">
            Signed in as {email} <span>✦</span>
          </div>
          <button className="logout-button" onClick={logOut}>
            <LogOut size={15} /> Log out
          </button>
        </header>
        <OfflineBanner />
        <main>
          {!(page === "matches" && chat) && (
            <div className="page-title">
              <div>
                <div className="eyebrow">FIND YOUR PEOPLE</div>
                <h1>{titles[page][0]}</h1>
                <p>{titles[page][1]}</p>
              </div>
            </div>
          )}
          {page === "discover" && <Discover me={me} onMatched={loadMatches} onOpenChat={openChat} />}
          {page === "matches" &&
            (chatId && !chat ? (
              matchState.loading ? (
                <Spinner label="Opening conversation…" />
              ) : (
                <ErrorNote error="This conversation is no longer available." onRetry={() => setChatId(null)} />
              )
            ) : chat ? (
              <Chat
                key={chat.match_id}
                me={me}
                match={chat}
                onBack={() => {
                  setChatId(null);
                  loadMatches();
                }}
                onClosed={loadMatches}
                onRead={refreshSoon}
              />
            ) : (
              <Matches
                me={me}
                matches={matchState.list}
                loading={matchState.loading}
                error={matchState.error}
                onRetry={loadMatches}
                onOpen={openChat}
                onDiscover={() => setPage("discover")}
              />
            ))}
          {page === "vibe" && <VibeReview uid={uid} answers={answers} setAnswers={setAnswers} />}
          {page === "profile" && (
            <div className="profile-page">
              <ProfileEditor uid={uid} profile={profile} mode="edit" onSaved={setProfile} />
            </div>
          )}
          <footer>
            <span>
              roomie. <small>A place to belong.</small>
            </span>
            <small>Compatibility is preference similarity, not a prediction. Students are not verified.</small>
          </footer>
        </main>
      </div>
    </>
  );
}
