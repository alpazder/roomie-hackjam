import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { ArrowLeft, Send, Ban, UserX, RotateCcw } from "lucide-react";
import { loadMessages, sendMessage, markRead, subscribeToMessages, unmatch, blockUser, newId, friendlyError } from "./api";
import { usePhotoUrls, UserAvatar, Spinner, ErrorNote, formatTime, useOnline } from "./common";

function mergeById(list, rows) {
  const map = new Map(list.map((m) => [m.id, m]));
  for (const r of rows) map.set(r.id, { ...map.get(r.id), ...r, status: "sent" });
  return [...map.values()].sort((a, b) => (a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0));
}

export default function Chat({ me, match, onBack, onClosed, onRead }) {
  const [messages, setMessages] = useState([]);
  const [pending, setPending] = useState([]); // { id, body, status: "sending" | "failed", error }
  const [state, setState] = useState({ loading: true, error: "", hasMore: false, loadingOlder: false });
  const [draft, setDraft] = useState("");
  const [closed, setClosed] = useState(false);
  const [confirm, setConfirm] = useState(""); // "" | "unmatch" | "block"
  const [actionError, setActionError] = useState("");
  const online = useOnline();
  const listRef = useRef(null);
  const stickToBottom = useRef(true);
  const urls = usePhotoUrls([match.photo_path]);
  const matchId = match.match_id;

  const read = useCallback(() => {
    markRead(matchId)
      .then(() => onRead?.())
      .catch(() => {});
  }, [matchId, onRead]);

  useEffect(() => {
    let live = true;
    setState({ loading: true, error: "", hasMore: false, loadingOlder: false });
    loadMessages(matchId)
      .then(({ rows, hasMore }) => {
        if (!live) return;
        setMessages((old) => mergeById(old, rows));
        setState({ loading: false, error: "", hasMore, loadingOlder: false });
        read();
      })
      .catch((err) => live && setState({ loading: false, error: friendlyError(err), hasMore: false, loadingOlder: false }));
    const stop = subscribeToMessages((row) => {
      setMessages((old) => mergeById(old, [row]));
      setPending((p) => p.filter((x) => x.id !== row.id));
      if (row.sender_id !== me.id) read();
    }, matchId);
    return () => {
      live = false;
      stop();
    };
  }, [matchId, me.id, read]);

  useLayoutEffect(() => {
    const el = listRef.current;
    if (el && stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [messages, pending]);

  async function older() {
    const oldest = messages[0];
    if (!oldest) return;
    const el = listRef.current;
    const prevHeight = el?.scrollHeight || 0;
    stickToBottom.current = false;
    setState((s) => ({ ...s, loadingOlder: true }));
    try {
      const { rows, hasMore } = await loadMessages(matchId, oldest.created_at);
      setMessages((old) => mergeById(old, rows));
      setState((s) => ({ ...s, hasMore, loadingOlder: false }));
      requestAnimationFrame(() => {
        if (el) el.scrollTop = el.scrollHeight - prevHeight;
      });
    } catch (err) {
      setState((s) => ({ ...s, loadingOlder: false, error: friendlyError(err) }));
    }
  }

  async function deliver(item) {
    setPending((p) => p.map((x) => (x.id === item.id ? { ...x, status: "sending", error: "" } : x)));
    try {
      const row = await sendMessage(item.id, matchId, item.body); // same id on retry → never duplicated
      setMessages((old) => mergeById(old, [row]));
      setPending((p) => p.filter((x) => x.id !== item.id));
    } catch (err) {
      const msg = friendlyError(err);
      if (/closed|Not a member/i.test(msg)) setClosed(true);
      setPending((p) => p.map((x) => (x.id === item.id ? { ...x, status: "failed", error: msg } : x)));
    }
  }

  function submit(e) {
    e.preventDefault();
    const body = draft.trim();
    if (!body || closed) return;
    const item = { id: newId(), body, status: "sending" };
    stickToBottom.current = true;
    setPending((p) => [...p, item]);
    setDraft("");
    deliver(item);
  }

  async function doAction(kind) {
    setActionError("");
    try {
      if (kind === "unmatch") await unmatch(matchId);
      else await blockUser(match.other_id);
      setClosed(true);
      onClosed?.();
    } catch (err) {
      setActionError(friendlyError(err));
    } finally {
      setConfirm("");
    }
  }

  return (
    <section className="chat" aria-label={`Conversation with ${match.display_name}`}>
      <header className="chat-header">
        <button className="icon-button" onClick={onBack} aria-label="Back to matches">
          <ArrowLeft size={18} />
        </button>
        <UserAvatar name={match.display_name} url={urls[match.photo_path]} className="row-avatar" />
        <span className="row-main">
          <b>{match.display_name}</b>
          <small>
            {match.major} · {match.university}
          </small>
        </span>
        {!closed && (
          <span className="chat-actions">
            {confirm ? (
              <>
                <button className="danger-button" onClick={() => doAction(confirm)}>
                  Confirm {confirm}
                </button>
                <button className="text-button" onClick={() => setConfirm("")}>
                  Cancel
                </button>
              </>
            ) : (
              <>
                <button className="text-button" onClick={() => setConfirm("unmatch")} title="Unmatch">
                  <UserX size={15} /> Unmatch
                </button>
                <button className="text-button danger" onClick={() => setConfirm("block")} title="Block">
                  <Ban size={15} /> Block
                </button>
              </>
            )}
          </span>
        )}
      </header>
      {confirm && (
        <p className="form-note chat-warning">
          {confirm === "block"
            ? `Blocking ends this conversation and hides you and ${match.display_name} from each other everywhere.`
            : `Unmatching ends this conversation. You won’t see each other in discovery again.`}
        </p>
      )}
      <ErrorNote error={actionError} />
      <div
        className="chat-messages"
        ref={listRef}
        onScroll={(e) => {
          const el = e.currentTarget;
          stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
        }}
      >
        {state.hasMore && (
          <button className="text-button load-older" onClick={older} disabled={state.loadingOlder}>
            {state.loadingOlder ? "Loading…" : "Load older messages"}
          </button>
        )}
        {state.loading ? (
          <Spinner label="Loading messages…" />
        ) : state.error && !messages.length ? (
          <ErrorNote error={state.error} />
        ) : !messages.length && !pending.length ? (
          <p className="chat-empty">You matched! Say hi and ask about their ideal weekday at home.</p>
        ) : null}
        {messages.map((m) => (
          <div key={m.id} className={"bubble " + (m.sender_id === me.id ? "mine" : "theirs")}>
            <p>{m.body}</p>
            <small>{formatTime(m.created_at)}</small>
          </div>
        ))}
        {pending.map((m) => (
          <div key={m.id} className={"bubble mine " + m.status}>
            <p>{m.body}</p>
            {m.status === "sending" ? (
              <small>Sending…</small>
            ) : (
              <small className="send-failed">
                Not sent. {m.error}{" "}
                {!closed && (
                  <button className="text-button" onClick={() => deliver(m)}>
                    <RotateCcw size={12} /> Retry
                  </button>
                )}
              </small>
            )}
          </div>
        ))}
      </div>
      {closed ? (
        <p className="chat-closed">This conversation is closed. No more messages can be sent.</p>
      ) : (
        <form className="chat-composer" onSubmit={submit}>
          <textarea
            rows={1}
            maxLength={2000}
            placeholder={online ? "Write a message…" : "You’re offline"}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) submit(e);
            }}
            aria-label="Message"
          />
          <button className="primary" type="submit" disabled={!draft.trim() || !online} aria-label="Send message">
            <Send size={17} />
          </button>
        </form>
      )}
    </section>
  );
}
