import React, { useEffect, useState } from "react";
import { Check, WifiOff } from "lucide-react";
import { signedPhotoUrls } from "./api";

export function useOnline() {
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);
  return online;
}

export function OfflineBanner() {
  const online = useOnline();
  if (online) return null;
  return (
    <div className="offline-banner" role="status">
      <WifiOff size={15} /> You’re offline. Changes won’t save until you reconnect.
    </div>
  );
}

export function usePhotoUrls(paths) {
  const key = paths.filter(Boolean).sort().join("|");
  const [urls, setUrls] = useState({});
  useEffect(() => {
    let live = true;
    if (!key) return;
    signedPhotoUrls(key.split("|"))
      .then((u) => live && setUrls((old) => ({ ...old, ...u })))
      .catch(() => {});
    return () => {
      live = false;
    };
  }, [key]);
  return urls;
}

export function UserAvatar({ name, url, className = "" }) {
  const initials = (name || "?")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join("");
  return (
    <div className={"avatar " + className} style={{ background: "#d9cef5" }}>
      <span>{initials || "?"}</span>
      {url && <img src={url} alt={name || "Profile photo"} onError={(e) => (e.currentTarget.style.display = "none")} />}
    </div>
  );
}

export function Spinner({ label = "Loading…" }) {
  return (
    <div className="loading-state" role="status">
      <span className="spinner" aria-hidden="true" />
      {label}
    </div>
  );
}

export function ErrorNote({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="error-note" role="alert">
      <span>{error}</span>
      {onRetry && (
        <button className="text-button" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

const STEPS = ["Account", "Profile", "Your vibe", "Discover"];
export function Stepper({ current }) {
  return (
    <ol className="stepper" aria-label="Onboarding progress">
      {STEPS.map((s, i) => (
        <li key={s} className={i < current ? "done" : i === current ? "current" : ""} aria-current={i === current ? "step" : undefined}>
          <span>{i < current ? <Check size={13} /> : i + 1}</span>
          {s}
        </li>
      ))}
    </ol>
  );
}

export function formatDate(d) {
  if (!d) return "";
  const date = new Date(d.length === 10 ? d + "T00:00:00" : d);
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export function formatTime(ts) {
  const d = new Date(ts);
  const today = new Date();
  return d.toDateString() === today.toDateString()
    ? d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })
    : d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
