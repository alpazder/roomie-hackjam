import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Heart, X, Sparkles, MapPin, CalendarDays, GraduationCap, MessageCircle } from "lucide-react";
import { discoverCandidates, recordSwipe, friendlyError } from "./api";
import { rankUsers, userBreakdown, explainUsers } from "../scenarios";
import { usePhotoUrls, UserAvatar, Spinner, ErrorNote, formatDate } from "./common";

export default function Discover({ me, onMatched, onOpenChat }) {
  const [state, setState] = useState({ loading: true, error: "", people: [] });
  const [busy, setBusy] = useState(false);
  const [swipeError, setSwipeError] = useState("");
  const [details, setDetails] = useState(null);
  const [match, setMatch] = useState(null);
  const [drag, setDrag] = useState(0);
  const start = useRef(null);

  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: "" }));
    try {
      const people = await discoverCandidates();
      setState({ loading: false, error: "", people });
    } catch (err) {
      setState({ loading: false, error: friendlyError(err), people: [] });
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  // Re-rank whenever my answers or budget change.
  const ranked = useMemo(() => rankUsers(me, state.people), [me, state.people]);
  const person = ranked[0];
  const urls = usePhotoUrls(ranked.slice(0, 5).map((p) => p.photo_path));

  async function act(action) {
    if (!person || busy) return;
    setBusy(true);
    setSwipeError("");
    try {
      const result = await recordSwipe(person.id, action);
      setState((s) => ({ ...s, people: s.people.filter((p) => p.id !== person.id) }));
      if (result?.matched) {
        setMatch({ person, matchId: result.match_id });
        onMatched?.();
      }
    } catch (err) {
      setSwipeError(friendlyError(err));
      if (/no longer available/i.test(err.message || "")) setState((s) => ({ ...s, people: s.people.filter((p) => p.id !== person.id) }));
    } finally {
      setBusy(false);
      setDrag(0);
    }
  }

  if (state.loading) return <Spinner label="Finding roommates…" />;
  if (state.error) return <ErrorNote error={state.error} onRetry={load} />;

  return (
    <div className="discovery min-w-0">
      <section className="swipe-area">
        <div className="deck-heading">
          <span>
            <span className="live-dot" /> RANKED BY YOUR ANSWERS
          </span>
          <small>
            {ranked.length} {ranked.length === 1 ? "person" : "people"} to explore
          </small>
        </div>
        {person ? (
          <>
            <div className="card-stack">
              <div className="stack-back" />
              <article
                className="profile-card"
                style={{ transform: drag ? `translateX(${drag}px) rotate(${drag / 20}deg)` : undefined }}
                onPointerDown={(e) => {
                  if (e.target.closest("button")) return;
                  start.current = e.clientX;
                  e.currentTarget.setPointerCapture(e.pointerId);
                }}
                onPointerMove={(e) => start.current !== null && setDrag(e.clientX - start.current)}
                onPointerUp={() => {
                  if (drag > 80) act("like");
                  else if (drag < -80) act("pass");
                  else setDrag(0);
                  start.current = null;
                }}
                onPointerCancel={() => {
                  setDrag(0);
                  start.current = null;
                }}
              >
                <div className="hero-photo">
                  <UserAvatar name={person.display_name} url={urls[person.photo_path]} />
                  <span className="student-tag">
                    <GraduationCap size={14} /> Student (not verified)
                  </span>
                  <div className="photo-gradient" />
                  <div className="photo-name">
                    <h2>{person.display_name}</h2>
                    <p>
                      <MapPin size={15} /> {person.preferred_city}
                    </p>
                  </div>
                  <button className="compat-pill" onClick={() => setDetails(person)}>
                    <Sparkles size={15} />
                    {person.fit == null ? "Not enough answers" : `${person.fit}% similar`}
                  </button>
                  {Math.abs(drag) > 40 && <div className={`swipe-stamp ${drag > 0 ? "like" : ""}`}>{drag > 0 ? "LIKE" : "PASS"}</div>}
                </div>
                <div className="card-body">
                  <div className="school">
                    <GraduationCap size={17} />
                    <div>
                      {person.university}
                      <small>
                        {person.major} · ${Number(person.budget).toLocaleString()}/mo budget
                      </small>
                    </div>
                  </div>
                  <p className="card-meta">
                    <CalendarDays size={14} /> Moving in {formatDate(person.move_in_date)}
                  </p>
                  {person.bio && <p className="bio">{person.bio}</p>}
                  {person.interests?.length > 0 && (
                    <div className="tags">
                      {person.interests.map((t) => (
                        <span key={t}>{t}</span>
                      ))}
                    </div>
                  )}
                </div>
              </article>
            </div>
            <ErrorNote error={swipeError} />
            <div className="swipe-controls">
              <button className="pass" onClick={() => act("pass")} disabled={busy} aria-label={`Pass on ${person.display_name}`}>
                <X size={31} />
              </button>
              <button className="like" onClick={() => act("like")} disabled={busy} aria-label={`Like ${person.display_name}`}>
                <Heart size={29} fill="currentColor" />
              </button>
            </div>
            <p className="swipe-hint">{busy ? "Saving…" : "Swipe or tap. A match needs both of you to like each other."}</p>
          </>
        ) : (
          <div className="empty-state">
            <Sparkles size={40} />
            <h2>No one new right now.</h2>
            <p>You’ve seen everyone who has finished onboarding and turned on discovery. Check back as more students join.</p>
            <button className="primary" onClick={load}>
              Refresh
            </button>
          </div>
        )}
      </section>
      <aside className="insights">
        <div className="insight-card">
          <div className="insight-title">
            <span className="sparkle-box">
              <Sparkles size={21} />
            </span>
            <span>
              How ranking works
              <small>PREFERENCE SIMILARITY</small>
            </span>
          </div>
          <p>
            We compare your scenario answers with theirs in four areas (cleanliness, sleep, guests, pets) plus both budgets. Dealbreakers
            count 3×. Areas either of you skipped aren’t counted. It’s a similarity estimate, not a prediction.
          </p>
        </div>
        <div className="demo-note">
          PRIVATE BY DESIGN
          <p>Likes stay private unless they’re mutual. Emails are never shown. Messaging unlocks only after a match.</p>
        </div>
      </aside>

      {details && (
        <div className="modal-backdrop isolate" onClick={() => setDetails(null)}>
          <section role="dialog" aria-modal="true" aria-label="Compatibility details" className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="close" aria-label="Close dialog" onClick={() => setDetails(null)}>
              <X />
            </button>
            <h2>You + {details.display_name}</h2>
            <p className="big-score">{details.fit == null ? "Not enough answers yet" : `${details.fit}% similar`}</p>
            <div className="breakdown">
              {userBreakdown(me, details).map((x) => (
                <div key={x.key}>
                  <span>
                    {x.label}
                    <small>{x.detail}</small>
                  </span>
                  <div className="meter">
                    <i style={{ width: (x.value ?? 0) + "%" }} />
                  </div>
                  <b>{x.value == null ? "—" : x.value + "%"}</b>
                </div>
              ))}
            </div>
            <div className="explanation">
              <Sparkles size={19} />
              <p>{explainUsers(me, details)}</p>
            </div>
          </section>
        </div>
      )}

      {match && (
        <div className="modal-backdrop isolate" onClick={() => setMatch(null)}>
          <section role="dialog" aria-modal="true" aria-label="It's a match" className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="match-celebration">
              <Sparkles size={38} />
              <div className="match-avatars">
                <UserAvatar name={me.display_name} url={me.photoUrl} className="large-avatar" />
                <Heart fill="currentColor" />
                <UserAvatar name={match.person.display_name} url={urls[match.person.photo_path]} />
              </div>
              <div className="eyebrow">THE FEELING IS MUTUAL</div>
              <h2>It’s a roomie match!</h2>
              <p>You and {match.person.display_name} liked each other. You can message each other now.</p>
              <button
                className="primary"
                onClick={() => {
                  const id = match.matchId;
                  setMatch(null);
                  onOpenChat(id);
                }}
              >
                <MessageCircle size={16} /> Send a message
              </button>
              <button className="text-button" onClick={() => setMatch(null)}>
                Keep discovering
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
