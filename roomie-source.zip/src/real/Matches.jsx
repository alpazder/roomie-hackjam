import React from "react";
import { Heart, MessageCircle } from "lucide-react";
import { usePhotoUrls, UserAvatar, Spinner, ErrorNote, formatTime } from "./common";
import { fitUsers } from "../scenarios";

export default function Matches({ me, matches, loading, error, onRetry, onOpen, onDiscover }) {
  const urls = usePhotoUrls(matches.map((m) => m.photo_path));
  if (loading && !matches.length) return <Spinner label="Loading matches…" />;
  if (error && !matches.length) return <ErrorNote error={error} onRetry={onRetry} />;
  if (!matches.length)
    return (
      <div className="empty-state">
        <Heart size={42} />
        <h2>No matches yet.</h2>
        <p>When you and someone else both like each other, they’ll show up here and you can start chatting.</p>
        <button className="primary" onClick={onDiscover}>
          Explore people
        </button>
      </div>
    );
  return (
    <>
      <ErrorNote error={error} onRetry={onRetry} />
      <div className="section-label">
        {matches.length} mutual {matches.length === 1 ? "connection" : "connections"}
      </div>
      <div className="conversation-list">
        {matches.map((m) => {
          const fit = fitUsers(me, { budget: m.budget, answers: m.answers });
          return (
            <button key={m.match_id} className="conversation-row" onClick={() => onOpen(m.match_id)}>
              <UserAvatar name={m.display_name} url={urls[m.photo_path]} className="row-avatar" />
              <span className="row-main">
                <b>
                  {m.display_name}
                  {fit != null && <em className="row-fit">{fit}% similar</em>}
                </b>
                <small>
                  {m.last_message
                    ? `${m.last_sender_id === me.id ? "You: " : ""}${m.last_message}`
                    : `Matched ${formatTime(m.matched_at)}. Say hi!`}
                </small>
              </span>
              <span className="row-side">
                {m.last_message_at && <small>{formatTime(m.last_message_at)}</small>}
                {m.unread_count > 0 ? (
                  <b className="badge" aria-label={`${m.unread_count} unread`}>
                    {m.unread_count}
                  </b>
                ) : (
                  <MessageCircle size={16} />
                )}
              </span>
            </button>
          );
        })}
      </div>
    </>
  );
}
