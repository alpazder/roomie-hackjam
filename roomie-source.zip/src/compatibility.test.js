import { test } from "node:test";
import assert from "node:assert/strict";
import { score, breakdown, explain } from "./compatibility.js";
import { defaultProfile, people } from "./data.js";
test("identical preferences score 100", () =>
  assert.equal(score(defaultProfile, defaultProfile), 100));
test("all five factors are bounded", () => {
  for (const p of people) {
    const b = breakdown(defaultProfile, p);
    assert.equal(b.length, 5);
    for (const x of b) assert.ok(x.value >= 0 && x.value <= 100);
    assert.ok(score(defaultProfile, p) >= 0 && score(defaultProfile, p) <= 100);
  }
});
test("budget mismatch lowers score", () =>
  assert.ok(score(defaultProfile, { ...defaultProfile, budget: 2000 }) < 100));
test("explanations identify non-AI source", () =>
  assert.match(explain(defaultProfile, people[0]), /not AI/));
