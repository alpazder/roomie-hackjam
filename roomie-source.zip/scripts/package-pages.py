from pathlib import Path
import re
p=Path('dist');s=(p/'index.html').read_text()
s=re.sub(r'<script type="module"[^>]*src="([^"]+)"[^>]*></script>',lambda m:'<script type="module">'+(p/m[1].lstrip('/')).read_text().replace('</script','<\\/script')+'</script>',s)
s=re.sub(r'<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>',lambda m:'<style>'+(p/m[1].lstrip('/')).read_text()+'</style>' if m[1].startswith('/assets/') else m[0],s)
out=Path('/tmp/roomie-publish');out.mkdir(exist_ok=True);(out/'index.html').write_text(s)
print('Packaged /tmp/roomie-publish/index.html')
