import {defineConfig} from 'vite';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({plugins:[tailwindcss()],build:{assetsInlineLimit:2000000,chunkSizeWarningLimit:1800}});
