// POST /api/chat  { me, profile, messages: [{ role: "user"|"assistant", text }] } → { reply, provider }
// Gemini replies in character for a SAMPLE demo profile. It is labeled as AI in the UI
// and is never used for chats between real accounts.
import { generate, handleCors, readBody, cleanPerson, cleanMessages, SAFETY } from "./_lib/gemini.js";
import { fallbackChatReply } from "../src/aiFallbacks.js";

function system(p, me) {
  return `You are role-playing ${p.name || "a student"}, a SAMPLE roommate profile in a college roommate-matching demo app, texting with ${me.name || "a student"} who just matched with you.
Profile: ${JSON.stringify(p)}.
Reply like a real college student texting: casual, friendly, 1–3 short sentences, at most one emoji. Stay consistent with the profile's major, school, bio, tags and lifestyle traits.
If asked whether you are real or an AI, say you're an AI demo replying for this sample profile.
Do not share or ask for phone numbers, addresses, social handles or money. Suggest meeting only in public places. ${SAFETY}`;
}

export default async function handler(req, res) {
  if (handleCors(req, res)) return;
  const body = readBody(req) || {};
  const me = cleanPerson(body.me);
  const profile = cleanPerson(body.profile);
  const messages = cleanMessages(body.messages);
  if (!messages.length || messages.at(-1).role !== "user")
    return res.status(400).json({ error: "Send at least one user message." });
  const transcript = messages
    .map((m) => `${m.role === "user" ? me.name || "Them" : profile.name || "You"}: ${m.text}`)
    .join("\n");
  try {
    let reply = await generate({
      system: system(profile, me),
      prompt: `Conversation so far:\n${transcript}\n\nWrite ${profile.name || "your"}'s next message only.`,
      maxOutputTokens: 200,
      temperature: 0.9,
    });
    reply = reply.replace(new RegExp(`^${(profile.name || "").split(" ")[0]}\\s*:\\s*`, "i"), "").trim().slice(0, 600);
    return res.status(200).json({ reply, provider: "Gemini" });
  } catch {
    return res.status(200).json({ reply: fallbackChatReply(profile, messages), provider: "fallback" });
  }
}
