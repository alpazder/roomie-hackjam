// Shared server-side Gemini helper for the Vercel functions in /api.
// The key is read from the server environment only and never sent to the browser.
// Files under api/_lib are not exposed as routes by Vercel.
import { GoogleGenAI } from "@google/genai";

export const TIMEOUT_MS = () => Number(process.env.GEMINI_TIMEOUT_MS) || 8000;
export const model = () => process.env.GEMINI_MODEL || "gemini-2.5-flash";

let client = null;
let clientKey = null;
function getClient() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  if (!client || clientKey !== key) {
    const baseUrl = process.env.GEMINI_BASE_URL; // only used by tests
    client = new GoogleGenAI({ apiKey: key, ...(baseUrl ? { httpOptions: { baseUrl } } : {}) });
    clientKey = key;
  }
  return client;
}

/** Calls Gemini with an ~8 s timeout. Resolves to text, or throws. */
export async function generate({ system, prompt, json = false, maxOutputTokens = 400, temperature = 0.7 }) {
  const ai = getClient();
  if (!ai) throw new Error("GEMINI_API_KEY is not set");
  const controller = new AbortController();
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new Error("Gemini timed out"));
    }, TIMEOUT_MS());
  });
  try {
    const res = await Promise.race([
      ai.models.generateContent({
        model: model(),
        contents: prompt,
        config: {
          systemInstruction: system,
          maxOutputTokens,
          temperature,
          abortSignal: controller.signal,
          ...(json ? { responseMimeType: "application/json" } : {}),
        },
      }),
      timeout,
    ]);
    const text = (res?.text || "").trim();
    if (!text) throw new Error("Gemini returned no text");
    return text;
  } finally {
    clearTimeout(timer);
  }
}

// Same origin rules as api/gemini.js: the GitHub Pages site plus any extra
// origins listed in ROOMIE_ALLOWED_ORIGINS (comma separated).
export function handleCors(req, res) {
  const origin = req.headers?.origin;
  const allowed = [
    "https://alpazder.github.io",
    ...(process.env.ROOMIE_ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean),
  ];
  const host = req.headers?.host;
  const sameOrigin = origin && host && (origin === `https://${host}` || origin === `http://${host}`);
  if (origin && (allowed.includes(origin) || sameOrigin)) res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Cache-Control", "no-store");
  if (origin && !allowed.includes(origin) && !sameOrigin) {
    res.status(403).json({ error: "Origin not allowed." });
    return true;
  }
  if (req.method === "OPTIONS") {
    res.status(204).end();
    return true;
  }
  if (req.method !== "POST") {
    res.status(405).json({ error: "Use POST." });
    return true;
  }
  return false;
}

export function readBody(req) {
  let body = req.body;
  if (typeof body === "string") {
    try {
      body = JSON.parse(body);
    } catch {
      return null;
    }
  }
  return body && typeof body === "object" ? body : null;
}

const clip = (v, n) => (typeof v === "string" ? v.slice(0, n) : typeof v === "number" && Number.isFinite(v) ? v : undefined);
const list = (v, n, each) => (Array.isArray(v) ? v.slice(0, n).map((x) => clip(String(x), each)) : undefined);

/** Whitelist and size-limit profile fields before they reach the prompt. */
export function cleanPerson(p = {}) {
  if (!p || typeof p !== "object") return {};
  return Object.fromEntries(
    Object.entries({
      name: clip(p.name, 60),
      age: clip(p.age, 3),
      year: clip(p.year, 20),
      university: clip(p.university || p.school, 100),
      major: clip(p.major, 80),
      bio: clip(p.bio, 350),
      tags: list(p.tags || p.interests, 8, 30),
      budget: clip(p.budget, 6),
      traits: p.traits && typeof p.traits === "object"
        ? Object.fromEntries(
            Object.entries(p.traits)
              .slice(0, 8)
              .map(([k, v]) => [clip(k, 20), clip(typeof v === "number" ? v : String(v), 30)]),
          )
        : undefined,
      clean: clip(p.clean, 2),
      sleep: clip(p.sleep, 20),
      guests: clip(p.guests, 20),
      pets: clip(p.pets, 20),
    }).filter(([, v]) => v !== undefined && v !== ""),
  );
}

export function cleanMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages
    .slice(-12)
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.text === "string")
    .map((m) => ({ role: m.role, text: m.text.slice(0, 500) }));
}

export const SAFETY =
  "Never infer or mention race, religion, ethnicity, sexual orientation, health, or other protected traits. Never invent contact details, addresses, or real-world facts about anyone.";
