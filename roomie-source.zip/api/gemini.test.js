import { test } from "node:test";
import assert from "node:assert/strict";
import handler from "./gemini.js";
function response() {
  return {
    code: 0,
    data: null,
    setHeader() {},
    status(n) {
      this.code = n;
      return this;
    },
    json(d) {
      this.data = d;
      return this;
    },
    end() {
      return this;
    },
  };
}
test("missing server configuration never pretends to generate AI advice", async () => {
  const oldKey = process.env.GEMINI_API_KEY,
    oldModel = process.env.GEMINI_MODEL;
  delete process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_MODEL;
  try {
    const r = response();
    await handler({ method: "POST" }, r);
    assert.equal(r.code, 503);
    assert.equal(r.data.provider, undefined);
  } finally {
    if (oldKey) process.env.GEMINI_API_KEY = oldKey;
    if (oldModel) process.env.GEMINI_MODEL = oldModel;
  }
});
