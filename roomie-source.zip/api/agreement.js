// POST /api/agreement  { me, profile, friction } → { markdown, provider }
import { generate, handleCors, readBody, cleanPerson, SAFETY } from "./_lib/gemini.js";
import { fallbackAgreement } from "../src/aiFallbacks.js";

const SYSTEM = `Write a short, friendly, fair roommate agreement in Markdown for two college students.
Sections (as bold labels or ### headings): Quiet hours, Guests, Cleaning & chores, Kitchen, Bills, How we handle disagreements.
Use specific, balanced compromises based on the two profiles and the friction point. Under 250 words. No preamble. ${SAFETY}`;

export default async function handler(req, res) {
  if (handleCors(req, res)) return;
  const body = readBody(req) || {};
  const me = cleanPerson(body.me);
  const profile = cleanPerson(body.profile);
  const f = body.friction && typeof body.friction === "object" ? body.friction : null;
  const friction = f
    ? { topic: String(f.topic || "").slice(0, 60), detail: String(f.detail || "").slice(0, 300), suggestion: String(f.suggestion || "").slice(0, 300) }
    : null;
  try {
    let markdown = await generate({
      system: SYSTEM,
      prompt: JSON.stringify({ roommateA: me, roommateB: profile, frictionPoint: friction }),
      maxOutputTokens: 700,
      temperature: 0.5,
    });
    markdown = markdown.replace(/^```(?:markdown|md)?\s*|```\s*$/g, "").trim();
    const words = markdown.split(/\s+/);
    if (words.length > 300) markdown = words.slice(0, 260).join(" ") + "…";
    return res.status(200).json({ markdown, provider: "Gemini" });
  } catch {
    return res.status(200).json({ markdown: fallbackAgreement(me, profile, friction), provider: "fallback" });
  }
}
