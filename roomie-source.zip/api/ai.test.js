// Tests for /api/explain, /api/agreement and /api/chat against a local mock of
// the Gemini REST API (no real key or network needed).
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import explain from "./explain.js";
import agreement from "./agreement.js";
import chat from "./chat.js";

let server, mode = "ok", lastRequest = null;
const replies = {
  explain: JSON.stringify({
    strengths: ["Both early risers", "Budgets within $100", "Both like a tidy kitchen"],
    friction: { topic: "Guests", detail: "Abrey rarely hosts; you like friends over.", suggestion: "Weeknight guests by 10 pm." },
    icebreaker: "Hey Abrey! Coffee before your 8am?",
  }),
  agreement: "### Quiet hours\nAfter 11 pm on weeknights.",
  chat: "Haha same! I'm usually up by 7 for class 😅",
};
let replyKey = "explain";

before(async () => {
  server = http.createServer((req, res) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => {
      lastRequest = { url: req.url, body: JSON.parse(data || "{}"), key: req.headers["x-goog-api-key"] };
      if (mode === "slow") return setTimeout(() => res.end("{}"), 3000);
      if (mode === "error") {
        res.writeHead(500, { "content-type": "application/json" });
        return res.end(JSON.stringify({ error: { code: 500, message: "boom", status: "INTERNAL" } }));
      }
      const text = mode === "badjson" ? "not json at all" : replies[replyKey];
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ candidates: [{ content: { role: "model", parts: [{ text }] }, finishReason: "STOP" }] }));
    });
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  process.env.GEMINI_BASE_URL = `http://127.0.0.1:${server.address().port}`;
  process.env.GEMINI_TIMEOUT_MS = "1000";
});
after(() => server.close());

function call(handler, body, headers = {}) {
  const r = { code: 0, data: null, headers: {}, setHeader(k, v) { this.headers[k] = v; }, status(n) { this.code = n; return this; }, json(d) { this.data = d; return this; }, end() { return this; } };
  return handler({ method: "POST", headers, body }, r).then(() => r);
}
const me = { name: "Alp", budget: 1100, major: "CS" };
const profile = { id: "abrey", name: "Abrey Biscardi", major: "Demo student", school: "USF", budget: 950, clean: 2, sleep: "Early bird", guests: "Rarely", pets: "No pets" };

test("explain returns Gemini JSON in the agreed shape, using JSON mode and the server key", async () => {
  process.env.GEMINI_API_KEY = "test-key";
  mode = "ok"; replyKey = "explain";
  const r = await call(explain, { me, profile, score: 72 });
  assert.equal(r.code, 200);
  assert.equal(r.data.provider, "Gemini");
  assert.equal(r.data.strengths.length, 3);
  assert.deepEqual(Object.keys(r.data.friction).sort(), ["detail", "suggestion", "topic"]);
  assert.match(r.data.icebreaker, /Abrey/);
  assert.equal(lastRequest.key, "test-key");
  assert.match(lastRequest.url, /gemini-2\.5-flash:generateContent/);
  assert.equal(lastRequest.body.generationConfig.responseMimeType, "application/json");
});

test("explain falls back cleanly on bad JSON, errors, timeouts, and a missing key", async () => {
  process.env.GEMINI_API_KEY = "test-key";
  for (const m of ["badjson", "error", "slow"]) {
    mode = m;
    const t0 = Date.now();
    const r = await call(explain, { me, profile, score: 72 });
    assert.equal(r.code, 200, m);
    assert.equal(r.data.provider, "fallback", m);
    assert.equal(r.data.strengths.length, 3);
    assert.ok(r.data.friction.topic && r.data.icebreaker);
    if (m === "slow") assert.ok(Date.now() - t0 < 2500, "timeout respected");
  }
  delete process.env.GEMINI_API_KEY;
  mode = "ok";
  const r = await call(explain, { me, profile });
  assert.equal(r.data.provider, "fallback");
});

test("agreement returns markdown from Gemini, or a fallback agreement", async () => {
  process.env.GEMINI_API_KEY = "test-key";
  mode = "ok"; replyKey = "agreement";
  let r = await call(agreement, { me, profile, friction: { topic: "Guests", detail: "x", suggestion: "y" } });
  assert.equal(r.data.provider, "Gemini");
  assert.match(r.data.markdown, /Quiet hours/);
  mode = "error";
  r = await call(agreement, { me, profile, friction: { topic: "Guests", suggestion: "Text first" } });
  assert.equal(r.data.provider, "fallback");
  assert.match(r.data.markdown, /Bills/);
  assert.ok(r.data.markdown.split(/\s+/).length < 250);
});

test("chat replies in character, sends the profile and history, and falls back", async () => {
  process.env.GEMINI_API_KEY = "test-key";
  mode = "ok"; replyKey = "chat";
  const messages = [{ role: "user", text: "hey! are you a morning person?" }];
  let r = await call(chat, { me, profile, messages });
  assert.equal(r.data.provider, "Gemini");
  assert.match(r.data.reply, /up by 7/);
  const sys = JSON.stringify(lastRequest.body.systemInstruction);
  assert.match(sys, /Abrey Biscardi/);
  assert.match(sys, /AI demo/);
  assert.match(JSON.stringify(lastRequest.body.contents), /morning person/);
  mode = "slow";
  r = await call(chat, { me, profile, messages });
  assert.equal(r.data.provider, "fallback");
  assert.ok(r.data.reply.length > 0);
});

test("chat rejects empty history and limits oversized input", async () => {
  process.env.GEMINI_API_KEY = "test-key";
  mode = "ok"; replyKey = "chat";
  let r = await call(chat, { me, profile, messages: [] });
  assert.equal(r.code, 400);
  const many = Array.from({ length: 40 }, (_, i) => ({ role: i % 2 ? "assistant" : "user", text: "x".repeat(2000) }));
  many.push({ role: "user", text: "last" });
  r = await call(chat, { me, profile, messages: many });
  assert.equal(r.data.provider, "Gemini");
  assert.ok(JSON.stringify(lastRequest.body.contents).length < 12 * 520 + 2000);
});

test("other websites cannot use the endpoints", async () => {
  const r = await call(chat, { me, profile, messages: [{ role: "user", text: "hi" }] }, { origin: "https://evil.example" });
  assert.equal(r.code, 403);
});
