// POST /api/explain  { me, profile, score }
// → { strengths: [3], friction: { topic, detail, suggestion }, icebreaker, provider }
import { generate, handleCors, readBody, cleanPerson, SAFETY } from "./_lib/gemini.js";
import { fallbackExplain } from "../src/aiFallbacks.js";

const SYSTEM = `You explain roommate compatibility for a college roommate-matching app.
Use only the two profiles and the numeric score provided. The score is computed elsewhere; do not change it.
Be specific, casual and brief. ${SAFETY}
Return JSON only, exactly:
{"strengths":["...","...","..."],"friction":{"topic":"...","detail":"...","suggestion":"..."},"icebreaker":"..."}
Each strength under 14 words. The icebreaker is one friendly first message the user could send.`;

function valid(x) {
  return (
    x &&
    Array.isArray(x.strengths) &&
    x.strengths.length >= 3 &&
    x.strengths.every((s) => typeof s === "string" && s.trim()) &&
    x.friction &&
    ["topic", "detail", "suggestion"].every((k) => typeof x.friction[k] === "string" && x.friction[k].trim()) &&
    typeof x.icebreaker === "string" &&
    x.icebreaker.trim()
  );
}

export default async function handler(req, res) {
  if (handleCors(req, res)) return;
  const body = readBody(req) || {};
  const me = cleanPerson(body.me);
  const profile = cleanPerson(body.profile);
  const score = Number.isFinite(body.score) ? Math.round(body.score) : null;
  try {
    const text = await generate({
      system: SYSTEM,
      prompt: JSON.stringify({ me, match: profile, compatibilityPercent: score }),
      json: true,
      maxOutputTokens: 500,
      temperature: 0.6,
    });
    const parsed = JSON.parse(text.replace(/^```(?:json)?|```$/g, "").trim());
    if (!valid(parsed)) throw new Error("Unexpected JSON shape");
    return res.status(200).json({
      strengths: parsed.strengths.slice(0, 3).map((s) => s.trim()),
      friction: {
        topic: parsed.friction.topic.trim(),
        detail: parsed.friction.detail.trim(),
        suggestion: parsed.friction.suggestion.trim(),
      },
      icebreaker: parsed.icebreaker.trim(),
      provider: "Gemini",
    });
  } catch {
    return res.status(200).json({ ...fallbackExplain(me, profile), provider: "fallback" });
  }
}
