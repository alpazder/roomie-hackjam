import {people} from '../src/data.js';
import {scenarios,actions,fit} from '../src/scenarios.js';
export default async function handler(req,res){
 const origin=req.headers?.origin;const allowed=['https://alpazder.github.io',...(process.env.ROOMIE_ALLOWED_ORIGINS||'').split(',').filter(Boolean)];
 if(origin&&allowed.includes(origin))res.setHeader('Access-Control-Allow-Origin',origin);
 res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Cache-Control','no-store');
 if(origin&&!allowed.includes(origin))return res.status(403).json({error:'Origin not allowed.'});
 if(req.method==='OPTIONS')return res.status(204).end();
 if(req.method!=='POST')return res.status(405).json({error:'Use POST.'});
 if(!process.env.GEMINI_API_KEY||!process.env.GEMINI_MODEL)return res.status(503).json({error:'Gemini is not configured. Set GEMINI_API_KEY and GEMINI_MODEL on the server.'});
 let body=req.body;try{if(typeof body==='string')body=JSON.parse(body)}catch{return res.status(400).json({error:'Invalid request.'})}
 const person=people.find(p=>p.id===body?.personId);if(!person||!Number.isFinite(body?.budget)||body.budget<500||body.budget>2500||!Array.isArray(body?.answers)||body.answers.length<1||body.answers.length>scenarios.length||new Set(body.answers.map(a=>a.id)).size!==body.answers.length||body.answers.some(a=>!scenarios.some(s=>s.id===a.id)||!Object.hasOwn(actions,a.action)))return res.status(400).json({error:'Provide a valid budget, sample profile, and scenario answers.'});
 const preferences={budget:person.budget,clean:person.clean,sleep:person.sleep,guests:person.guests,pets:person.pets};
 const choices=body.answers.map(x=>({scenario:scenarios.find(s=>s.id===x.id).text,response:actions[x.action].label}));
 try{const result=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(process.env.GEMINI_MODEL)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:'You are a student roommate conversation coach. Use only supplied sample lifestyle preferences and scenario choices. In under 120 words describe one alignment, one possible friction, and one concrete question to discuss. This is self-reported preference data, not proof of honesty or personality. Do not claim a successful tenancy is predicted. Never infer protected traits. Do not invent facts. The numeric score is calculated externally, not by you.'}]},contents:[{parts:[{text:JSON.stringify({studentBudget:body.budget,sampleRoommatePreferences:preferences,scenarioChoices:choices,numericalSimilarity:fit({budget:body.budget},person,body.answers)})}]}],generationConfig:{maxOutputTokens:600,temperature:.5}}),signal:AbortSignal.timeout(15000)});
 if(!result.ok)return res.status(502).json({error:'Gemini could not complete this request. Check the model, key, and quota on the server.'});
 const data=await result.json();const text=data.candidates?.[0]?.content?.parts?.filter(x=>!x.thought).map(x=>x.text||'').join('').trim();
 if(!text)return res.status(502).json({error:'Gemini returned no usable explanation.'});
 return res.status(200).json({provider:'Gemini',text,model:data.modelVersion||process.env.GEMINI_MODEL});
 }catch{return res.status(502).json({error:'Gemini timed out or could not be reached.'})}
}
