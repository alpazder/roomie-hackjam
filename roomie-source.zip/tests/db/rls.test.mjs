// Database rule tests: run the real migrations on a scratch PostgreSQL database
// (with a small Supabase stand-in) and act as several signed-in users.
//   DATABASE_URL=postgres://postgres@localhost:5432/postgres npm run test:db
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { randomUUID } from "node:crypto";
import pg from "pg";

const ADMIN_URL = process.env.DATABASE_URL;
if (!ADMIN_URL) {
  console.log("Skipping DB tests: set DATABASE_URL to a PostgreSQL server you can create databases on.");
  process.exit(0);
}
const DB = `roomie_test_${Date.now()}`;
const root = new URL("../../", import.meta.url);
let pool;

const SCENARIOS = ["dishes", "late", "friends", "cat", "morning", "tidy", "quiet", "dog", "counter", "weekend"];

async function asUser(uid, sql, params = [], client) {
  const c = client || (await pool.connect());
  try {
    await c.query("begin");
    await c.query(uid ? "set local role authenticated" : "set local role anon");
    await c.query("select set_config('request.jwt.claim.sub', $1, true)", [uid || ""]);
    const r = await c.query(sql, params);
    await c.query("commit");
    return r;
  } catch (e) {
    await c.query("rollback").catch(() => {});
    throw e;
  } finally {
    if (!client) c.release();
  }
}
const admin = (sql, params) => pool.query(sql, params);

async function newUser(label) {
  const id = randomUUID();
  await admin("insert into auth.users (id, email) values ($1, $2)", [id, `${label}-${id.slice(0, 6)}@test.dev`]);
  return id;
}
async function onboard(uid, extra = {}) {
  await asUser(
    uid,
    `update public.profiles set display_name = $2, university = 'USF', major = 'CS',
       budget = $3, preferred_city = 'Tampa', move_in_date = '2027-01-01', onboarding_step = 'vibe'
     where id = $1`,
    [uid, extra.name || "Test", extra.budget || 1000],
  );
  for (const s of SCENARIOS)
    await asUser(uid, "insert into public.scenario_answers (user_id, scenario_id, action) values ($1, $2, 'right')", [uid, s]);
  await asUser(uid, "update public.profiles set onboarding_step = 'done' where id = $1", [uid]);
}
const swipe = (uid, target, action = "like", client) =>
  asUser(uid, "select public.record_swipe($1, $2) as r", [target, action], client).then((r) => r.rows[0].r);
const send = (uid, id, match, body) =>
  asUser(uid, "select * from public.send_message($1, $2, $3)", [id, match, body]).then((r) => r.rows[0]);

before(async () => {
  const boot = new pg.Client({ connectionString: ADMIN_URL });
  await boot.connect();
  await boot.query(`create database ${DB}`);
  await boot.end();
  const url = new URL(ADMIN_URL);
  url.pathname = "/" + DB;
  pool = new pg.Pool({ connectionString: url.toString(), max: 12 });
  await admin(readFileSync(new URL("tests/db/supabase_stub.sql", root), "utf8"));
  const dir = new URL("supabase/migrations/", root);
  for (const f of readdirSync(dir).sort()) await admin(readFileSync(new URL(f, dir), "utf8"));
});
after(async () => {
  await pool?.end();
  const boot = new pg.Client({ connectionString: ADMIN_URL });
  await boot.connect();
  await boot.query(`drop database if exists ${DB} with (force)`);
  await boot.end();
});

test("sign-up creates a private profile row; onboarding gates are enforced server-side", async () => {
  const a = await newUser("a");
  const own = await asUser(a, "select * from public.profiles where id = $1", [a]);
  assert.equal(own.rows[0].onboarding_step, "profile");
  assert.ok(!("email" in own.rows[0]), "profiles never store email");

  await assert.rejects(
    asUser(a, "update public.profiles set onboarding_step = 'vibe' where id = $1", [a]),
    /Complete the required profile fields/,
  );
  await asUser(a, `update public.profiles set display_name='A', university='USF', major='CS', budget=900,
                   preferred_city='Tampa', move_in_date='2027-01-01', onboarding_step='vibe' where id=$1`, [a]);
  await assert.rejects(
    asUser(a, "update public.profiles set onboarding_step = 'done' where id = $1", [a]),
    /Answer all 10 scenarios/,
  );
  for (const s of SCENARIOS)
    await asUser(a, "insert into public.scenario_answers (user_id, scenario_id, action) values ($1,$2,'left')", [a, s]);
  await asUser(a, "update public.profiles set onboarding_step = 'done' where id = $1", [a]);
  await assert.rejects(
    asUser(a, "delete from public.scenario_answers where user_id = $1", [a]).then((r) => {
      if (r.rowCount === 0) throw new Error("no rows deleted after onboarding");
    }),
    /no rows deleted/,
  );
  await asUser(a, "update public.scenario_answers set action = 'up' where user_id = $1 and scenario_id = 'cat'", [a]);
});

test("users cannot read or change someone else's profile, answers, or photo path", async () => {
  const a = await newUser("a"), b = await newUser("b");
  await onboard(a);
  await onboard(b);
  const seen = await asUser(a, "select * from public.profiles where id = $1", [b]);
  assert.equal(seen.rowCount, 0);
  const upd = await asUser(a, "update public.profiles set display_name = 'hacked' where id = $1", [b]);
  assert.equal(upd.rowCount, 0);
  await assert.rejects(
    asUser(a, "insert into public.scenario_answers (user_id, scenario_id, action) values ($1, 'cat', 'up')", [b]),
    /row-level security/,
  );
  await assert.rejects(
    asUser(a, "update public.profiles set photo_path = $2 where id = $1", [a, `${b}/x.jpg`]),
    /Invalid photo path/,
  );
  await assert.rejects(asUser(a, "select public.answers_json($1)", [b]), /permission denied/);
});

test("anonymous visitors cannot call matching functions", async () => {
  const a = await newUser("a");
  await assert.rejects(asUser(null, "select public.record_swipe($1, 'like')", [a]), /permission denied/);
  await assert.rejects(asUser(null, "select * from public.discover_candidates()"), /permission denied/);
});

test("discovery shows only other eligible users and needs finished onboarding", async () => {
  const a = await newUser("a"), b = await newUser("b"), half = await newUser("half"), hidden = await newUser("hidden");
  await onboard(a);
  await onboard(b);
  await onboard(hidden);
  await asUser(hidden, "update public.profiles set discoverable = false where id = $1", [hidden]);
  const ids = (await asUser(a, "select id from public.discover_candidates()")).rows.map((r) => r.id);
  assert.ok(ids.includes(b));
  assert.ok(!ids.includes(a), "never yourself");
  assert.ok(!ids.includes(half), "incomplete onboarding excluded");
  assert.ok(!ids.includes(hidden), "discovery-disabled excluded");
  await assert.rejects(asUser(half, "select * from public.discover_candidates()"), /Finish onboarding/);
  await assert.rejects(swipe(a, hidden), /no longer available/);
});

test("a one-sided like is private and does not create a match", async () => {
  const a = await newUser("a"), b = await newUser("b");
  await onboard(a);
  await onboard(b);
  const r = await swipe(a, b);
  assert.equal(r.matched, false);
  const bSees = await asUser(b, "select * from public.swipes");
  assert.equal(bSees.rowCount, 0, "B cannot see A's incoming like");
  const matches = await admin("select * from public.matches where $1 in (user_a, user_b)", [a]);
  assert.equal(matches.rowCount, 0);
  await assert.rejects(
    asUser(b, "insert into public.swipes (swiper_id, target_id, action) values ($1, $2, 'like')", [a, b]),
    /permission denied/,
  );
  await assert.rejects(
    asUser(a, "insert into public.matches (user_a, user_b) values (least($1::uuid,$2::uuid), greatest($1::uuid,$2::uuid))", [a, b]),
    /permission denied/,
  );
  const ids = (await asUser(a, "select id from public.discover_candidates()")).rows.map((x) => x.id);
  assert.ok(!ids.includes(b), "acted-on profiles leave discovery");
});

test("mutual likes create exactly one match, and repeats are idempotent", async () => {
  const a = await newUser("a"), b = await newUser("b");
  await onboard(a);
  await onboard(b);
  await swipe(a, b);
  const r = await swipe(b, a);
  assert.equal(r.matched, true);
  const again = await swipe(b, a);
  assert.equal(again.match_id, r.match_id);
  await swipe(a, b);
  const rows = await admin("select * from public.matches where user_a = least($1::uuid,$2::uuid) and user_b = greatest($1::uuid,$2::uuid)", [a, b]);
  assert.equal(rows.rowCount, 1);
  const am = await asUser(a, "select * from public.my_matches()");
  const bm = await asUser(b, "select * from public.my_matches()");
  assert.equal(am.rows[0].other_id, b);
  assert.equal(bm.rows[0].other_id, a);
});

test("concurrent mutual likes still create exactly one match", async () => {
  for (let i = 0; i < 15; i++) {
    const a = await newUser("ca"), b = await newUser("cb");
    await onboard(a);
    await onboard(b);
    const [c1, c2] = await Promise.all([pool.connect(), pool.connect()]);
    try {
      const [r1, r2] = await Promise.all([swipe(a, b, "like", c1), swipe(b, a, "like", c2)]);
      assert.ok(r1.matched || r2.matched, "at least one side sees the match");
    } finally {
      c1.release();
      c2.release();
    }
    const n = await admin("select count(*)::int n from public.matches where user_a = least($1::uuid,$2::uuid) and user_b = greatest($1::uuid,$2::uuid)", [a, b]);
    assert.equal(n.rows[0].n, 1);
  }
});

test("messaging: members only, idempotent retries, unread state, third user locked out", async () => {
  const a = await newUser("a"), b = await newUser("b"), c = await newUser("c");
  await onboard(a);
  await onboard(b);
  await onboard(c);
  await swipe(a, b);
  const { match_id } = await swipe(b, a);

  const id = randomUUID();
  const m1 = await send(a, id, match_id, "Hey! <script>alert(1)</script>");
  assert.equal(m1.sender_id, a);
  const retry = await send(a, id, match_id, "Hey! <script>alert(1)</script>");
  assert.equal(retry.id, m1.id);
  const count = await admin("select count(*)::int n from public.messages where match_id = $1", [match_id]);
  assert.equal(count.rows[0].n, 1, "retrying the same id never duplicates");

  const bRead = await asUser(b, "select body from public.messages where match_id = $1", [match_id]);
  assert.equal(bRead.rows[0].body, "Hey! <script>alert(1)</script>", "stored as plain text");

  let bm = (await asUser(b, "select * from public.my_matches()")).rows[0];
  assert.equal(bm.unread_count, 1);
  await asUser(b, "select public.mark_read($1)", [match_id]);
  bm = (await asUser(b, "select * from public.my_matches()")).rows[0];
  assert.equal(bm.unread_count, 0);

  const cRead = await asUser(c, "select * from public.messages where match_id = $1", [match_id]);
  assert.equal(cRead.rowCount, 0, "third user cannot read");
  await assert.rejects(send(c, randomUUID(), match_id, "let me in"), /Not a member/);
  await assert.rejects(asUser(c, "select public.mark_read($1)", [match_id]), /Not a member/);
  await assert.rejects(
    asUser(a, "insert into public.messages (id, match_id, sender_id, body) values ($1, $2, $3, 'forged')", [randomUUID(), match_id, b]),
    /permission denied/,
  );
  await assert.rejects(send(c, id, match_id, "reuse id"), /Not a member/);
  await assert.rejects(send(a, randomUUID(), match_id, "   "), /1–2000/);
});

test("one-sided likes cannot message", async () => {
  const a = await newUser("a"), b = await newUser("b");
  await onboard(a);
  await onboard(b);
  await swipe(a, b);
  const fake = randomUUID();
  await assert.rejects(send(a, randomUUID(), fake, "hi"), /Not a member/);
});

test("unmatch and block stop messaging and remove the pair from discovery", async () => {
  const a = await newUser("a"), b = await newUser("b"), c = await newUser("c");
  await onboard(a);
  await onboard(b);
  await onboard(c);

  await swipe(a, b);
  const { match_id: ab } = await swipe(b, a);
  await send(a, randomUUID(), ab, "hello");
  await asUser(b, "select public.unmatch($1)", [ab]);
  await assert.rejects(send(a, randomUUID(), ab, "still there?"), /conversation is closed/);
  assert.equal((await asUser(a, "select * from public.my_matches()")).rowCount, 0);
  const aDisc = (await asUser(a, "select id from public.discover_candidates()")).rows.map((r) => r.id);
  assert.ok(!aDisc.includes(b));

  await swipe(a, c);
  const { match_id: ac } = await swipe(c, a);
  await asUser(c, "select public.block_user($1)", [a]);
  await assert.rejects(send(a, randomUUID(), ac, "hi?"), /conversation is closed/);
  await assert.rejects(send(c, randomUUID(), ac, "hi?"), /conversation is closed/);
  const fresh = await newUser("d");
  await onboard(fresh);
  await asUser(fresh, "select public.block_user($1)", [a]);
  const aSees = (await asUser(a, "select id from public.discover_candidates()")).rows.map((r) => r.id);
  const dSees = (await asUser(fresh, "select id from public.discover_candidates()")).rows.map((r) => r.id);
  assert.ok(!aSees.includes(fresh), "blocked user disappears for the blocked person");
  assert.ok(!dSees.includes(a), "and for the blocker");
  await assert.rejects(swipe(a, fresh), /no longer available/);
});

test("photo storage: owners write their own folder; viewers need permission", async () => {
  const a = await newUser("a"), b = await newUser("b"), c = await newUser("c");
  await onboard(a);
  await onboard(b);
  await onboard(c);
  await asUser(a, "insert into storage.objects (bucket_id, name) values ('avatars', $1)", [`${a}/me.jpg`]);
  await assert.rejects(
    asUser(a, "insert into storage.objects (bucket_id, name) values ('avatars', $1)", [`${b}/me.jpg`]),
    /row-level security/,
  );
  const cSees = await asUser(c, "select name from storage.objects where name = $1", [`${a}/me.jpg`]);
  assert.equal(cSees.rowCount, 1);
  await asUser(a, "select public.block_user($1)", [c]);
  const cBlocked = await asUser(c, "select name from storage.objects where name = $1", [`${a}/me.jpg`]);
  assert.equal(cBlocked.rowCount, 0);
  const bucket = await admin("select * from storage.buckets where id = 'avatars'");
  assert.equal(bucket.rows[0].public, false);
  assert.equal(Number(bucket.rows[0].file_size_limit), 3145728);
});
