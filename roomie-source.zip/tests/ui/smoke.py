# UI smoke test against the in-memory fake backend.
#   npx vite build --config tests/ui/vite.fake.config.js
#   (cd /tmp/roomie-fake && python3 -m http.server 8790) &
#   python3 tests/ui/smoke.py
import sys
from playwright.sync_api import sync_playwright, expect

URL = "http://localhost:8790/"
SHOTS = "/tmp/roomie-shots"
errors = []
steps = []

def step(name):
    steps.append(name)
    print("✓", name)

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    ctx = b.new_context(viewport={"width": 1280, "height": 900})
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: m.type == "error" and "Failed to load resource" not in m.text and errors.append(m.text))
    import os; os.makedirs(SHOTS, exist_ok=True)

    pg.goto(URL)
    expect(pg.get_by_role("heading", name="Welcome back.")).to_be_visible()
    pg.screenshot(path=f"{SHOTS}/01-login.png")
    step("auth screen renders")

    pg.get_by_label("Email").fill("me@test.dev")
    pg.get_by_label("Password").fill("wrongpass1")
    pg.get_by_role("button", name="Log in", exact=True).click()
    expect(pg.get_by_role("alert")).to_contain_text("don’t match")
    step("wrong password shows a friendly error")

    pg.get_by_label("Password").fill("password123")
    pg.get_by_role("button", name="Log in", exact=True).click()
    expect(pg.get_by_role("heading", name="Tell people about you.")).to_be_visible()
    step("new account lands on Profile step")

    pg.get_by_role("button", name="Save and continue").click()
    expect(pg.locator(".field-error").first).to_be_visible()
    step("required fields are validated")

    pg.locator("label:has-text('Display name') input").fill("Alp Test")
    pg.locator("label:has-text('Major') input").fill("Computer Engineering")
    pg.locator("input[type=date]").fill("2027-01-15")
    pg.locator(".interest-input input").fill("basketball, coffee")
    pg.keyboard.press("Enter")
    pg.screenshot(path=f"{SHOTS}/02-profile.png", full_page=True)
    pg.get_by_role("button", name="Save and continue").click()
    expect(pg.get_by_role("heading", name="Your vibe: 10 everyday moments.")).to_be_visible()
    step("profile saves and advances to Your vibe")

    def answer(direction):
        pg.locator(f".scenario-action.{direction}").click()
        pg.wait_for_timeout(450)

    answer("right"); answer("right"); answer("left")
    pg.get_by_role("button", name="Undo last answer").click()
    pg.wait_for_timeout(300)
    expect(pg.locator(".scenario-progress b")).to_contain_text("2 / 10")
    step("answers save one at a time; undo works")

    pg.reload()
    expect(pg.get_by_role("heading", name="Your vibe: 10 everyday moments.")).to_be_visible()
    expect(pg.locator(".scenario-progress b")).to_contain_text("2 / 10")
    step("onboarding resumes after refresh at the same answer")

    # remaining scenarios in order: friends, cat, morning, tidy, quiet, dog, counter, weekend
    for d in ["left", "right", "right", "right", "right", "right", "right", "left"]:
        answer(d)
    expect(pg.locator(".scenario-progress b")).to_contain_text("10 / 10")
    pg.screenshot(path=f"{SHOTS}/03-vibe-done.png")
    pg.get_by_role("button", name="Finish and start discovering").first.click()
    expect(pg.get_by_role("heading", name="Good vibes. Great roommates.")).to_be_visible()
    step("finishing onboarding opens Discover")

    expect(pg.locator(".photo-name h2")).to_have_text("Sam Rivera")
    pct = pg.locator(".compat-pill").inner_text()
    pg.screenshot(path=f"{SHOTS}/04-discover.png")
    pg.locator(".compat-pill").click()
    expect(pg.get_by_role("dialog", name="Compatibility details")).to_be_visible()
    pg.screenshot(path=f"{SHOTS}/05-details.png")
    pg.get_by_role("button", name="Close dialog").click()
    step(f"discover ranks the most similar person first ({pct})")

    pg.get_by_role("button", name="Like Sam Rivera").click()
    expect(pg.get_by_role("heading", name="It’s a roomie match!")).to_be_visible()
    pg.screenshot(path=f"{SHOTS}/06-match.png")
    step("mutual like shows the match notification")

    pg.get_by_role("button", name="Send a message").click()
    expect(pg.get_by_role("region", name="Conversation with Sam Rivera")).to_be_visible()
    box = pg.get_by_role("textbox", name="Message")
    box.fill("Hello <b>bold</b>?")
    box.press("Enter")
    expect(pg.locator(".bubble.mine p").last).to_have_text("Hello <b>bold</b>?")
    assert pg.locator(".bubble b").count() == 0, "user HTML must not render"
    step("messages send and render as plain text")

    pg.evaluate("window.__failNextSend = true")
    box.fill("retry me")
    box.press("Enter")
    expect(pg.locator(".bubble.failed")).to_contain_text("Not sent")
    pg.locator(".bubble.failed").get_by_role("button", name="Retry").click()
    expect(pg.locator(".bubble.failed")).to_have_count(0)
    expect(pg.locator(".bubble.sending")).to_have_count(0)
    n = pg.evaluate("window.__fakeDb.messages.filter(m => m.body === 'retry me').length")
    assert n == 1, n
    step("failed send shows error, retry delivers exactly once")

    pg.evaluate("window.__fakeReply('Hi back! Love the dishes answer.')")
    expect(pg.locator(".bubble.theirs p")).to_have_text("Hi back! Love the dishes answer.")
    pg.screenshot(path=f"{SHOTS}/07-chat.png")
    step("incoming realtime message appears")

    pg.get_by_role("button", name="Back to matches").click()
    pg.evaluate("window.__fakeReply('Are you free to tour Saturday?')")
    expect(pg.locator(".conversation-row .badge")).to_have_text("1")
    expect(pg.locator("nav .badge")).to_have_text("1")
    pg.screenshot(path=f"{SHOTS}/08-matches.png")
    step("unread badges update on the Matches page")

    pg.reload()
    pg.get_by_role("button", name="Matches").click()
    expect(pg.locator(".conversation-row .badge")).to_have_text("1")
    pg.locator(".conversation-row").click()
    expect(pg.locator(".bubble")).to_have_count(4)
    pg.get_by_role("button", name="Back to matches").click()
    expect(pg.locator(".conversation-row .badge")).to_have_count(0)
    step("after refresh: session, history and unread state persist; opening marks read")

    pg.get_by_role("button", name="Your vibe").click()
    pg.locator(".review-row").nth(2).get_by_role("radio", name="Works for me").click()
    pg.wait_for_timeout(200)
    v = pg.evaluate("window.__fakeDb.answers.find(a => a.scenario_id === 'friends' && a.user_id.endsWith('1')).action")
    assert v == "right", v
    step("answers can be revisited later")

    pg.get_by_role("button", name="My profile").click()
    pg.get_by_label("Show me in discovery").uncheck()
    pg.get_by_role("button", name="Save profile").click()
    expect(pg.get_by_role("status").filter(has_text="Saved.")).to_be_visible()
    step("discovery visibility can be turned off")

    pg.get_by_role("button", name="Matches").click()
    pg.locator(".conversation-row").click()
    pg.get_by_role("button", name="Block").click()
    pg.get_by_role("button", name="Confirm block").click()
    expect(pg.locator(".chat-closed")).to_be_visible()
    step("block closes the conversation")

    m = ctx.new_page()
    m.set_viewport_size({"width": 390, "height": 844})
    m.goto(URL)
    m.get_by_role("button", name="Discover").click()
    m.screenshot(path=f"{SHOTS}/09-mobile-discover.png")
    m.get_by_role("button", name="Matches").click()
    m.screenshot(path=f"{SHOTS}/10-mobile-matches.png")
    m.close()

    pg.get_by_role("button", name="Log out").first.click()
    expect(pg.get_by_role("heading", name="Welcome back.")).to_be_visible()
    step("log out returns to the login screen")

    pg.get_by_role("button", name="Try demo mode (sample profiles, no account)").click()
    expect(pg.locator(".demo-banner")).to_be_visible()
    pg.screenshot(path=f"{SHOTS}/11-demo.png")
    pg.get_by_role("button", name="Sign in for real matching").click()
    expect(pg.get_by_role("heading", name="Welcome back.")).to_be_visible()
    step("demo mode is separate and clearly labeled")
    b.close()

print("\nconsole/page errors:", errors or "none")
sys.exit(1 if errors else 0)
