// Builds the app with the in-memory fake backend for the UI smoke test.
import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath } from "node:url";
const fake = fileURLToPath(new URL("./fakeSupabase.js", import.meta.url));
export default defineConfig({
  root: fileURLToPath(new URL("../../", import.meta.url)),
  base: "./",
  plugins: [
    tailwindcss(),
    {
      name: "fake-supabase",
      enforce: "pre",
      async resolveId(source, importer, opts) {
        if (!/supabase$/.test(source) || !importer?.includes("/src/")) return null;
        const r = await this.resolve(source, importer, { ...opts, skipSelf: true });
        return r && r.id.endsWith("/src/real/supabase.js") ? fake : null;
      },
    },
  ],
  build: { outDir: "/tmp/roomie-fake", emptyOutDir: true, assetsInlineLimit: 2000000 },
});
