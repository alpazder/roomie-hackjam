// Local stand-in for Vercel: serves dist/ and runs the /api functions,
// pointed at a mock Gemini server (or with Gemini disabled via NO_GEMINI=1).
import http from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";
const root = new URL("../../", import.meta.url).pathname;
const PORT = Number(process.env.PORT || 8797);

if (!process.env.NO_GEMINI) {
  const mock = http.createServer((req, res) => {
    let d = "";
    req.on("data", (c) => (d += c));
    req.on("end", () => {
      const body = JSON.parse(d || "{}");
      const sys = JSON.stringify(body.systemInstruction || "");
      let text;
      if (sys.includes("Return JSON only"))
        text = JSON.stringify({
          strengths: ["You both like a tidy kitchen", "Budgets within $150", "Similar weeknight routines"],
          friction: { topic: "Guests", detail: "One of you hosts more often.", suggestion: "Text before guests stay over." },
          icebreaker: "Hey! What does your perfect Sunday at home look like?",
        });
      else if (sys.includes("roommate agreement")) text = "### Quiet hours\nAfter 11 pm on weeknights.\n\n### Guests\nText first.";
      else text = "Haha nice! I'm usually up early for class, but I keep it quiet 😊";
      setTimeout(() => {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify({ candidates: [{ content: { role: "model", parts: [{ text }] } }] }));
      }, 300);
    });
  });
  await new Promise((r) => mock.listen(0, "127.0.0.1", r));
  process.env.GEMINI_API_KEY = "mock-key";
  process.env.GEMINI_BASE_URL = `http://127.0.0.1:${mock.address().port}`;
} else delete process.env.GEMINI_API_KEY;

const handlers = {
  explain: (await import(join(root, "api/explain.js"))).default,
  agreement: (await import(join(root, "api/agreement.js"))).default,
  chat: (await import(join(root, "api/chat.js"))).default,
};
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".jpg": "image/jpeg", ".svg": "image/svg+xml" };
http
  .createServer(async (req, res) => {
    const url = new URL(req.url, "http://x");
    const m = url.pathname.match(/^\/api\/(explain|agreement|chat)$/);
    if (m && !process.env.STATIC_ONLY) {
      let d = "";
      req.on("data", (c) => (d += c));
      req.on("end", () => {
        const out = {
          status(n) { res.statusCode = n; return out; },
          json(o) { res.setHeader("content-type", "application/json"); res.end(JSON.stringify(o)); return out; },
          setHeader: (k, v) => res.setHeader(k, v),
          end: () => res.end(),
        };
        handlers[m[1]]({ method: req.method, headers: req.headers, body: d }, out);
      });
      return;
    }
    const file = url.pathname === "/" ? "/index.html" : url.pathname;
    try {
      const data = await readFile(join(root, "dist", file));
      res.writeHead(200, { "content-type": types[extname(file)] || "application/octet-stream" });
      res.end(data);
    } catch {
      res.writeHead(404, { "content-type": "text/html" });
      res.end("<h1>404</h1>");
    }
  })
  .listen(PORT, () => console.log("listening", PORT));
