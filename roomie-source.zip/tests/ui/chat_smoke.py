# Browser test of Match Chat + Gemini features.
#   npm run build
#   node tests/ui/aiserver.mjs &                         # :8797 with mock Gemini
#   PORT=8798 STATIC_ONLY=1 node tests/ui/aiserver.mjs & # :8798 no API (like GitHub Pages)
#   python3 tests/ui/chat_smoke.py
from playwright.sync_api import sync_playwright, expect

errors = []

def run(base, label, expect_ai):
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
        pg = b.new_page(viewport={"width": 1280, "height": 900})
        pg.on("pageerror", lambda e: errors.append(f"{label}: {e}"))
        pg.goto(base)
        pg.get_by_role("tab", name="Sign up").click()
        pg.get_by_label("Username or email").fill("alp")
        pg.get_by_label("Password").fill("pw")
        pg.get_by_role("button", name="Create account").click()
        pg.get_by_label("Your name").fill("Alp")
        pg.get_by_label("University").fill("USF")
        pg.get_by_label("Major").fill("Computer Engineering")
        pg.get_by_role("button", name="Save my profile").click()
        for d in ["right", "left", "right"]:
            pg.locator(f".scenario-action.{d}").click(); pg.wait_for_timeout(250)
        pg.get_by_role("button", name="Discover").click()
        matched = None
        for _ in range(8):
            name = pg.locator(".photo-name h2").inner_text().split(",")[0].strip()
            pg.get_by_role("button", name="Like profile").click(); pg.wait_for_timeout(400)
            if pg.locator(".match-celebration").count():
                matched = name; break
        assert matched, "no match"
        box = pg.locator(".insights-box")
        expect(box.locator(".ai-label")).to_be_visible(timeout=12000)
        lbl = box.locator(".ai-label").inner_text()
        assert ("Gemini" in lbl and "not connected" not in lbl) == expect_ai, lbl
        assert box.locator("li").count() == 5
        pg.screenshot(path=f"/tmp/chat-{label}-1-match.png")
        print(f"[{label}] matched {matched}; insights: {lbl}")

        first = matched.split()[0]
        pg.get_by_role("button", name=f"Message {first}").click()
        expect(pg.get_by_role("region", name=f"Conversation with {matched}")).to_be_visible()
        chip = pg.locator(".chip.icebreaker")
        expect(chip).to_be_visible()
        chip.click()
        expect(pg.locator(".typing-bubble")).to_be_visible()
        expect(pg.locator(".bubble.theirs:not(.typing-bubble)")).to_have_count(1, timeout=12000)
        reply1 = pg.locator(".bubble.theirs p").first.inner_text()
        tag = pg.locator(".bubble.theirs small").first.inner_text()
        assert ("AI reply" in tag) == expect_ai, tag
        print(f"[{label}] icebreaker sent; reply ({tag.split('·')[-1].strip()}): {reply1}")

        box2 = pg.get_by_role("textbox", name="Message")
        box2.fill("What's your budget for rent?")
        box2.press("Enter")
        expect(pg.locator(".bubble.theirs:not(.typing-bubble)")).to_have_count(2, timeout=12000)
        print(f"[{label}] second reply: {pg.locator('.bubble.theirs p').nth(1).inner_text()}")
        pg.screenshot(path=f"/tmp/chat-{label}-2-chat.png")

        pg.get_by_role("button", name="Roommate Agreement").click()
        dlg = pg.get_by_role("dialog", name="Roommate agreement")
        expect(dlg.locator(".agreement-body h3, .agreement-body h2").first).to_be_visible(timeout=12000)
        print(f"[{label}] agreement: {dlg.locator('.ai-label').inner_text()[:40]}…")
        pg.screenshot(path=f"/tmp/chat-{label}-3-agreement.png")
        dlg.get_by_role("button", name="Close dialog").click()

        pg.get_by_role("button", name="Back to matches").click()
        row = pg.locator(".conversation-row").first
        expect(row).to_contain_text(matched)
        expect(pg.locator(".messages-button .badge")).to_have_text("1")
        pg.reload()
        pg.get_by_role("button", name="Messages, 1 matches").click()
        pg.locator(".conversation-row").first.click()
        expect(pg.locator(".bubble")).to_have_count(4)
        print(f"[{label}] list, header badge, and chat history persist after reload")
        pg.screenshot(path=f"/tmp/chat-{label}-4-list.png")
        b.close()

run("http://localhost:8797/", "gemini", True)
run("http://localhost:8798/", "noapi", False)
print("errors:", errors or "none")
