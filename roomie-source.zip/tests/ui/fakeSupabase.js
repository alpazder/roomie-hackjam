// In-memory stand-in for the Supabase client, used only by the UI smoke test
// (tests/ui/vite.fake.config.js swaps it in for src/real/supabase.js).
// It mimics the database functions' rules closely enough to drive every screen.
const ME = "00000000-0000-4000-8000-000000000001";
const SAM = "00000000-0000-4000-8000-000000000002";
const RIO = "00000000-0000-4000-8000-000000000003";
const ids = ["dishes", "late", "friends", "cat", "morning", "tidy", "quiet", "dog", "counter", "weekend"];

const db = {
  users: { "me@test.dev": { id: ME, password: "password123" } },
  profiles: {
    [ME]: { id: ME, display_name: "", university: null, major: null, bio: null, budget: null, preferred_city: null, move_in_date: null, interests: [], photo_path: null, discoverable: true, onboarding_step: "profile" },
    [SAM]: { id: SAM, display_name: "Sam Rivera", university: "University of South Florida (USF)", major: "Biology", bio: "Quiet mornings, clean kitchen.", budget: 1000, preferred_city: "Tampa, FL", move_in_date: "2027-01-10", interests: ["Running"], photo_path: null, discoverable: true, onboarding_step: "done" },
    [RIO]: { id: RIO, display_name: "Rio Park", university: "University of Tampa (UT)", major: "Film", bio: "Friends over often.", budget: 1400, preferred_city: "Tampa, FL", move_in_date: "2027-02-01", interests: ["Film"], photo_path: null, discoverable: true, onboarding_step: "done" },
  },
  answers: [
    ...ids.map((id) => ({ user_id: SAM, scenario_id: id, action: id === "friends" || id === "weekend" ? "left" : "right", answered_at: new Date().toISOString() })),
    ...ids.map((id) => ({ user_id: RIO, scenario_id: id, action: "left", answered_at: new Date().toISOString() })),
  ],
  swipes: [{ swiper_id: SAM, target_id: ME, action: "like" }],
  matches: [],
  messages: [],
  reads: [],
  blocks: [],
};
const saved = JSON.parse(localStorage.getItem("fake-db") || "null");
if (saved) Object.assign(db, saved);
const persist = () => localStorage.setItem("fake-db", JSON.stringify(db));
let session = JSON.parse(localStorage.getItem("fake-session") || "null");
const listeners = new Set();
const channels = new Set();
const ok = (data) => Promise.resolve({ data, error: null });
const fail = (message) => Promise.resolve({ data: null, error: { message } });
const emit = (event) => listeners.forEach((cb) => cb(event, session));
const uid = () => session?.user?.id;
const answersOf = (u) => db.answers.filter((a) => a.user_id === u).map((a) => ({ id: a.scenario_id, action: a.action }));
const complete = (p) => p.display_name && p.university && p.major && p.budget && p.preferred_city && p.move_in_date;

function table(name) {
  const filters = [];
  let mode = "select", payload = null, single = false, order = null, limit = null;
  const rows = () => {
    if (name === "profiles") return Object.values(db.profiles).filter((p) => p.id === uid());
    if (name === "scenario_answers") return db.answers.filter((a) => a.user_id === uid());
    if (name === "messages")
      return db.messages.filter((m) => db.matches.some((x) => x.id === m.match_id && [x.user_a, x.user_b].includes(uid())));
    return [];
  };
  const api = {
    select() { return api; },
    eq(c, v) { filters.push((r) => r[c] === v); return api; },
    in(c, vs) { filters.push((r) => vs.includes(r[c])); return api; },
    lt(c, v) { filters.push((r) => r[c] < v); return api; },
    order(c, o) { order = order || [c, o?.ascending !== false]; return api; },
    limit(n) { limit = n; return api; },
    single() { single = true; return api; },
    update(p) { mode = "update"; payload = p; return api; },
    upsert(p) { mode = "upsert"; payload = p; return api; },
    delete() { mode = "delete"; return api; },
    then(res, rej) { return run().then(res, rej); },
  };
  async function run() {
    await new Promise((r) => setTimeout(r, 60));
    try { return await run2(); } finally { persist(); }
  }
  async function run2() {
    if (mode === "upsert" && name === "scenario_answers") {
      if (payload.user_id !== uid()) return fail("new row violates row-level security policy");
      db.answers = db.answers.filter((a) => !(a.user_id === uid() && a.scenario_id === payload.scenario_id));
      db.answers.push(payload);
      return ok(null);
    }
    let list = rows().filter((r) => filters.every((f) => f(r)));
    if (mode === "delete") {
      if (db.profiles[uid()].onboarding_step === "done") return ok([]);
      db.answers = db.answers.filter((a) => !list.includes(a));
      return ok(null);
    }
    if (mode === "update") {
      const p = list[0];
      if (!p) return fail("no rows");
      const next = { ...p, ...payload };
      if (["vibe", "done"].includes(next.onboarding_step) && !complete(next)) return fail("Complete the required profile fields first.");
      if (next.onboarding_step === "done" && answersOf(uid()).length < 10) return fail("Answer all 10 scenarios first.");
      db.profiles[p.id] = next;
      list = [next];
    }
    if (order) list = [...list].sort((a, b) => (a[order[0]] < b[order[0]] ? -1 : 1) * (order[1] ? 1 : -1));
    if (limit) list = list.slice(0, limit);
    return ok(single ? list[0] : list);
  }
  return api;
}

function other(m) { return m.user_a === uid() ? m.user_b : m.user_a; }
const rpcs = {
  discover_candidates() {
    return Object.values(db.profiles)
      .filter((p) => p.id !== uid() && p.onboarding_step === "done" && p.discoverable)
      .filter((p) => !db.swipes.some((s) => s.swiper_id === uid() && s.target_id === p.id))
      .filter((p) => !db.matches.some((m) => [m.user_a, m.user_b].includes(p.id) && [m.user_a, m.user_b].includes(uid())))
      .map((p) => ({ ...p, answers: answersOf(p.id) }));
  },
  record_swipe({ p_target, p_action }) {
    if (!db.swipes.some((s) => s.swiper_id === uid() && s.target_id === p_target)) db.swipes.push({ swiper_id: uid(), target_id: p_target, action: p_action });
    const mutual = p_action === "like" && db.swipes.some((s) => s.swiper_id === p_target && s.target_id === uid() && s.action === "like");
    if (!mutual) return { matched: false, match_id: null };
    let m = db.matches.find((x) => [x.user_a, x.user_b].includes(p_target) && [x.user_a, x.user_b].includes(uid()));
    if (!m) db.matches.push((m = { id: "m-" + db.matches.length, user_a: uid(), user_b: p_target, created_at: new Date().toISOString(), ended_at: null }));
    return { matched: true, match_id: m.id };
  },
  my_matches() {
    return db.matches
      .filter((m) => [m.user_a, m.user_b].includes(uid()) && !m.ended_at)
      .map((m) => {
        const p = db.profiles[other(m)];
        const msgs = db.messages.filter((x) => x.match_id === m.id);
        const last = msgs.at(-1);
        const read = db.reads.find((r) => r.user_id === uid() && r.match_id === m.id)?.last_read_at || "";
        return {
          match_id: m.id, matched_at: m.created_at, other_id: p.id, ...p, answers: answersOf(p.id),
          last_message: last?.body, last_message_at: last?.created_at, last_sender_id: last?.sender_id,
          unread_count: msgs.filter((x) => x.sender_id !== uid() && x.created_at > read).length,
        };
      });
  },
  send_message({ p_id, p_match, p_body }) {
    const m = db.matches.find((x) => x.id === p_match);
    if (!m || ![m.user_a, m.user_b].includes(uid())) throw new Error("Not a member of this conversation.");
    if (m.ended_at) throw new Error("This conversation is closed.");
    if (window.__failNextSend) { window.__failNextSend = false; throw new Error("Failed to fetch"); }
    let row = db.messages.find((x) => x.id === p_id);
    if (!row) {
      row = { id: p_id, match_id: p_match, sender_id: uid(), body: p_body, created_at: new Date().toISOString() };
      db.messages.push(row);
      setTimeout(() => channels.forEach((c) => c.fire(row)), 30);
    }
    return row;
  },
  mark_read({ p_match }) {
    db.reads = db.reads.filter((r) => !(r.user_id === uid() && r.match_id === p_match));
    db.reads.push({ user_id: uid(), match_id: p_match, last_read_at: new Date().toISOString() });
    return null;
  },
  unmatch({ p_match }) { const m = db.matches.find((x) => x.id === p_match); m.ended_at = new Date().toISOString(); return null; },
  block_user({ p_target }) {
    db.blocks.push({ blocker_id: uid(), blocked_id: p_target });
    db.matches.forEach((m) => { if ([m.user_a, m.user_b].includes(p_target)) m.ended_at = new Date().toISOString(); });
    return null;
  },
};

// Test hook: simulate the matched person replying (arrives over "realtime").
window.__fakeReply = (body) => {
  const m = db.matches.find((x) => !x.ended_at);
  const row = { id: crypto.randomUUID(), match_id: m.id, sender_id: other(m), body, created_at: new Date().toISOString() };
  db.messages.push(row);
  persist();
  channels.forEach((c) => c.fire(row));
};
window.__fakeDb = db;

export const isSupabaseConfigured = true;
export const redirectUrl = () => location.href;
export const supabase = {
  auth: {
    getSession: () => ok({ session }),
    onAuthStateChange(cb) { listeners.add(cb); return { data: { subscription: { unsubscribe: () => listeners.delete(cb) } } }; },
    async signInWithPassword({ email, password }) {
      const u = db.users[email];
      if (!u || u.password !== password) return fail("Invalid login credentials");
      session = { user: { id: u.id, email } };
      localStorage.setItem("fake-session", JSON.stringify(session));
      emit("SIGNED_IN");
      return ok({ session });
    },
    async signUp() { return ok({ session: null, user: {} }); },
    async signOut() { session = null; localStorage.removeItem("fake-session"); emit("SIGNED_OUT"); return { error: null }; },
    resetPasswordForEmail: () => ok({}),
    updateUser: () => ok({}),
  },
  from: table,
  async rpc(name, args) {
    await new Promise((r) => setTimeout(r, 60));
    try { return { data: rpcs[name](args || {}), error: null }; } catch (e) { return { data: null, error: { message: e.message } }; } finally { persist(); }
  },
  storage: { from: () => ({ upload: () => ok({}), remove: () => ok({}), createSignedUrls: () => ok([]) }) },
  channel() {
    const handlers = [];
    const c = {
      on(_t, opts, cb) { handlers.push([opts, cb]); return c; },
      subscribe() { channels.add(c); return c; },
      fire(row) { handlers.forEach(([o, cb]) => { if (!o.filter || o.filter === `match_id=eq.${row.match_id}`) cb({ new: row }); }); },
    };
    return c;
  },
  removeChannel(c) { channels.delete(c); },
};
